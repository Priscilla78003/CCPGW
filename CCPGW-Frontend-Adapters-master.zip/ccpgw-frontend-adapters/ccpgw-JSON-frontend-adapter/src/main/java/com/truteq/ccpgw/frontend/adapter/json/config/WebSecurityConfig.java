///*
// * ***************************************************************
// * Truteq Internet Payment Gateway (IPGW) version 1.0.0
// * ***************************************************************
// * Copyright (c) 2021 Truteq Australia 2019
// * ***************************************************************
// * IPGW Front end Adapter: SABRE - Microservice for IPGW - SABRE 
// * Support: Grant O'Reilly gbo@truteq.com
// * V01.00.00  20-Nov-2020 
// * ***************************************************************
// */
//package com.truteq.ccpgw.frontend.adapter.json.config;
//
//import com.truteq.ccpgw.communication.server.logging.wrapper.LogWrapper;
//import com.truteq.general.util.AESEncryptionDecryption;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.Properties;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//
///**
// *
// * @author Grant Blaise O'Reilly <gbo@truteq.com>
// */
//@Configuration
//@EnableWebSecurity
//public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
//
//    private final LogWrapper mLogger = new LogWrapper(WebSecurityConfig.class);
//    private String userName;
//    private String password;
//    private String role;
//
//    private AESEncryptionDecryption decryptor;
//    private String decodedRole;
//    private String decodedUserName;
//    private String decodedPassword;
//
//    protected WebSecurityConfig() {
//
//        loadProperties("config/application.properties");
//
//        try {
//            decryptor = new AESEncryptionDecryption();
//            decodedRole = decryptor.decrypt(role, "adm1nttpp");
//            decodedUserName = decryptor.decrypt(userName, "adm1nttpp");
//            decodedPassword = decryptor.decrypt(password, "adm1nttpp");
//
//        } catch (Exception ex) {
//            mLogger.error("Exception in decrypting credentials." + ex);
//        }
//    }
//
//    public final void loadProperties(String filename) {
//
//        this.mLogger.debug("Working Directory = " + System.getProperty("user.dir"), new Throwable().getStackTrace()[0]);
//        try (InputStream input = new FileInputStream(filename)) {
//
//            Properties prop = new Properties();
//
//            // load a properties file
//            prop.load(input);
//
//            // get the property value and print it out
//            this.mLogger.debug("Username: " + prop.getProperty("json.rest.user.name"), new Throwable().getStackTrace()[0]);
//
//            this.userName = prop.getProperty("json.rest.user.name");
//            this.password = prop.getProperty("json.rest.password");
//            this.role = prop.getProperty("json.rest.role");
//
//        } catch (IOException ex) {
//            this.mLogger.error("Error load properties file: " + ex.getMessage(), new Throwable().getStackTrace()[0]);
//        }
//    }
//
//    @Override
//    protected void configure(HttpSecurity http) throws Exception {
//
//        http.csrf().disable()
//            .authorizeRequests()
//            .anyRequest().hasRole(decodedRole)
//            .and()
//            .httpBasic();                
//
//    }
//     
//
//    @Autowired
//    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//        auth
//                .inMemoryAuthentication()
//                .withUser(this.decodedUserName)
//                .password(passwordEncoder().encode(this.decodedPassword))
//                .roles(this.decodedRole);
//
//    }
//    
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//
//}
