 

http://gurgle:8081/

http://gurgle:8081/wp-admin/



![](images/gurgleLogin.png)





```http
https://ccpgw.testbsp.com.pg/keycloak/ccpgw/authenticate/authorise/order/payment
```



  financial : hostname + '/keycloak/ccpgw/authenticate/authorise/postilion/financial',

```java
@RestController
public class CCPGWAuthenticateAuthorisePostilionTransactionsController extends GenericAuthenticationAuthorisationController {

    private final LogWrapper mLogger = new LogWrapper(CCPGWAuthenticateAuthorisePostilionTransactionsController.class);

    @Autowired
    private HttpSession httpSession;

    @PostMapping(path = "/keycloak/ccpgw/authenticate/authorise/postilion/financial")
    @CrossOrigin(origins = "*")
    public String doFinancial(@RequestBody EncryptedCard cardpayment) throws IOException {

        MicroServiceHandler msh = new MicroServiceHandler(httpSession,
                ccpgwJsonFrontEndAdapterServerHostname + "/postilion/financial",
                keyCloakServerOpenIdConnectToken,
                aaClientId,
                aaClientSecret,
                "ccpgwuser",
                "ccpgwu53r");
        
        return msh.callMicroService(cardpayment.toJSON().getBytes());

    }
}
```



```java
public abstract class GenericAuthenticationAuthorisationController {
    
    //ccpgw.jsonfrontendadapter.server.hostname=http://10.160.30.95:9092/ccpgwjsonadapter
    //token.url=http://ccpgw.testbsp.com.pg:8181/auth/realms/PlatformPAC-CCPGW/protocol/openid-connect/token
    //aa.client.id=ccpgw-auth-service
    //aa.client.secret=d6af0239-9d73-4736-965d-1f01b983a4f2

    @Value(value = "${ccpgw.jsonfrontendadapter.server.hostname}")
    protected String ccpgwJsonFrontEndAdapterServerHostname;  

    @Value(value = "${token.url}")
    protected String keyCloakServerOpenIdConnectToken;  
    
    @Value(value = "${aa.client.id}")
    protected String aaClientId;  
    
    @Value(value = "${aa.client.secret}")
    protected String aaClientSecret;  
```







  getMerchant: hostname + '/keycloak/ccpgw/authenticate/authorise/merchant/read',
