docker rmi -f 73a7a2dca140
docker rmi -f a90f28f3aa92
docker rmi -f 9dc5462a6a2f
docker rmi -f b726810430e8


docker rmi -f 89205b215ece
docker rmi -f 18609d89605e
docker rmi -f 058a1bd512f2
docker rmi -f a95261b58b13
docker rmi -f e0c2960dfc6a
docker rmi -f 9ea69e4b5b63
docker rmi -f 05a61c0c7210
docker rmi -f dd8b034e0660
docker rmi -f cb065245b661
docker rmi -f 10b57f3a8fb2
docker rmi -f fa6a49d7f184
docker rmi -f b726810430e8
docker rmi -f 9dc5462a6a2f
docker rmi -f a90f28f3aa92
docker rmi -f 73a7a2dca140


docker rmi -f ebb5abc0e3d6
docker rmi -f 3abeea0b76fb
docker rmi -f 62d0e547cc20
docker rmi -f d9f75c678106
docker rmi -f 41a519b97579
docker rmi -f b30a6d716655
docker rmi -f 018f375eb370
docker rmi -f d07a814a7e68
docker rmi -f 432609d7d367
docker rmi -f 144003e74af0
docker rmi -f 6b901472f727
docker rmi -f 37180934046b
