/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.truteq.ccpgw.model.adapter.plugins.icbs;

/**
 *
 * @author Grant Blaise O'Reilly <gbo@truteq.com>
 */
public class Address {

    private String fullName;
    private String addr1;
    private String addr2;
    private String addr3;
    private String addr4;
    private String addr5;
    private String postalCode;
    private String postLocaleCode;
    private String countryCode;
    private String addrCode;

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * @return the addr1
     */
    public String getAddr1() {
        return addr1;
    }

    /**
     * @param addr1 the addr1 to set
     */
    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }

    /**
     * @return the addr2
     */
    public String getAddr2() {
        return addr2;
    }

    /**
     * @param addr2 the addr2 to set
     */
    public void setAddr2(String addr2) {
        this.addr2 = addr2;
    }

    /**
     * @return the addr3
     */
    public String getAddr3() {
        return addr3;
    }

    /**
     * @param addr3 the addr3 to set
     */
    public void setAddr3(String addr3) {
        this.addr3 = addr3;
    }

    /**
     * @return the addr4
     */
    public String getAddr4() {
        return addr4;
    }

    /**
     * @param addr4 the addr4 to set
     */
    public void setAddr4(String addr4) {
        this.addr4 = addr4;
    }

    /**
     * @return the addr5
     */
    public String getAddr5() {
        return addr5;
    }

    /**
     * @param addr5 the addr5 to set
     */
    public void setAddr5(String addr5) {
        this.addr5 = addr5;
    }

    /**
     * @return the postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * @param postalCode the postalCode to set
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     * @return the postLocaleCode
     */
    public String getPostLocaleCode() {
        return postLocaleCode;
    }

    /**
     * @param postLocaleCode the postLocaleCode to set
     */
    public void setPostLocaleCode(String postLocaleCode) {
        this.postLocaleCode = postLocaleCode;
    }

    /**
     * @return the countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * @param countryCode the countryCode to set
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * @return the addrCode
     */
    public String getAddrCode() {
        return addrCode;
    }

    /**
     * @param addrCode the addrCode to set
     */
    public void setAddrCode(String addrCode) {
        this.addrCode = addrCode;
    }
}
