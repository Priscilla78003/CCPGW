sudo docker build -t microservice-ccpgw-acs-servlet-1.2.0 .
