# Accessing GrantServer 



Hostname: grantserver

User: gbo

IP address: 192.168.224.20



```bash
(base) grant@grant-T490:~$ ssh gbo@grantserver
gbo@grantserver's password: 
Last login: Fri Nov  4 10:09:33 2022 from 192.168.224.163
[gbo@grantserver ~]$ ll
total 16
drwx------. 2 gbo  gbo   83 Oct 24 15:46 ./
drwxr-xr-x. 6 root root  58 Oct 24 15:21 ../
-rw-------. 1 gbo  gbo  273 Nov  4 10:38 .bash_history
-rw-r--r--. 1 gbo  gbo   18 Apr 12  2022 .bash_logout
-rw-r--r--. 1 gbo  gbo  141 Apr 12  2022 .bash_profile
-rw-r--r--. 1 gbo  gbo  376 Apr 12  2022 .bashrc
[gbo@grantserver ~]$ cd ..
[gbo@grantserver /home]$ ll
total 0
drwxr-xr-x.  6 root    root     58 Oct 24 15:21 ./
dr-xr-xr-x. 17 root    root    224 Oct 24 14:47 ../
drwx------.  2 gain    gain     62 Oct 24 14:54 gain/
drwx------.  2 gbo     gbo      83 Oct 24 15:46 gbo/
drwx------.  3 jhughes jhughes  95 Oct 24 15:21 jhughes/
drwx------.  2 truteq  truteq   83 Oct 24 15:36 truteq/
[gbo@grantserver /home]$ su -
Password: 
Last login: Fri Nov  4 10:10:06 AEST 2022 on pts/0
[root@grantserver ~]# ll
total 140
dr-xr-x---.  2 root root  4096 Oct 24 15:53 ./
dr-xr-xr-x. 17 root root   224 Oct 24 14:47 ../
-rw-------.  1 root root 17112 Oct 24 14:54 anaconda-ks.cfg
-rw-------.  1 root root  1042 Nov  4 10:10 .bash_history
-rw-r--r--.  1 root root    18 Mar 15  2021 .bash_logout
-rw-r--r--.  1 root root   176 Mar 15  2021 .bash_profile
-rw-r--r--.  1 root root   176 Mar 15  2021 .bashrc
-rw-r--r--.  1 root root   100 Mar 15  2021 .cshrc
-rw-------.  1 root root  6625 Oct 24 14:54 grub.cfg.osorig
-rw-r--r--.  1 root root   347 Oct 24 14:54 ifcfg-ens192
-rw-r--r--.  1 root root    61 Oct 24 14:47 ks-include-updates
-rw-r--r--.  1 root root   318 Oct 24 14:47 ks-network-include
-rw-r--r--.  1 root root    15 Oct 24 14:46 ks-packages
-rw-r--r--.  1 root root    61 Oct 24 14:46 ks-packages-truteq
-rwx------.  1 root root  8993 Oct 24 14:44 ks-script-6p5saqza*
-rwx------.  1 root root  4647 Oct 24 14:54 ks-script-eyn44wj6*
-rw-------.  1 root root 19067 Oct 24 14:55 original-ks.cfg
-rw-------.  1 root root  4269 Apr 12  2022 sshd_config.osorig
-rw-r--r--.  1 root root  1722 May  9  2022 system.conf.osorig
-rw-r--r--.  1 root root   129 Mar 15  2021 .tcshrc
-rw-r--r--.  1 root root   114 Oct 24 14:54 tt_ks-post.log
-rw-r--r--.  1 root root     0 Oct 24 14:44 tt_ks-pre.log
-rw-------.  1 root root  3037 Oct 24 15:53 .viminfo
-rw-r--r--.  1 root root  1982 Apr 27  2022 vimrc.osorig
[root@grantserver ~]# 

```

