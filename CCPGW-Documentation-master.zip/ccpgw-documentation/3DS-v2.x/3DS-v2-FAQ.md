  ![](../headerImages//PlatformPAC.png)



# Netcetera 3DS 2.x Frerquently Asked Questions (FAQ)  

###### version: 1.0.0

<img align="left" width="100" height="120" src="../headerImages//GrantOReilly.png"/>

Author: <span style="color:blue">**Grant Blaise O'Reilly PhD.**</span>

###### **Java Developer and System Architect**

email: grant@platformpac.com.pg

Hi Gjorgji,

When we have a card that does not require the browser challenge (i.e. the ACSUrl = null)  how do I trigger the  Notification coming from Netcetera Server? 

Currently the  the  Notification coming from Netcetera Server is trigger by the call to the ACSUrl (i.e. https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge) and I receive the notification request on my webservice (i.e. https://ccpgw.testbsp.com.pg/3dsnotification which I set up in the 3DS server Configurations).

However, when there is no call to the ACSUrl (i.e. NO browser challenge required) how do I trigger the notification request  coming from Netcetera?

Regards
Grant



Hi Grant, 

In case the cards don't request challenge, they will return the full result of the authentication in the ARes message. 

The response will be returned by the 3DS server on the environment from which it received the AReq, and it will store it in the  backend for reports and later analysis, and can be accessed by the transaction search feature. 

Depending on the transStatus field, if it is failed (N, R, U or A), will have info of the failure in the transStatusReason field, or if it is 'Y' it will be passed, and it will contain all the  details needed for authorization so you can process the transaction. 

I will include some links from the documentation on the ARes model and the flow: 

https://3dss.netcetera.com/3dsserver-saas/doc/2.5.2.1/3ds-2.x-api (check 3DS Authetnication) 

https://3dss.netcetera.com/3dsserver-saas/doc/2.5.2.1/3ds-authentication#authentication-response-model 

Please advise if the information is sufficient and how to proceed. Kind Regards, Gjorgji



No challenge

 {"threeDSServerTransID":"a009a157-8554-4605-855d-e83fa65d49e9","acsURL":null,"transStatus":"Y","authenticationValue":"MTIzNDU2Nzg5MDA5ODc2NTQ
zMjE=","eci":"02","acsChallengeMandated":null,"authenticationRequest":{"threeDSCompInd":"Y","threeDSRequestorID":"ds-assigned-requestor-id","threeDSRequestorName":"ds-assigned-requestor-name","threeDSRequestorURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-me
thod","acquirerBIN":"428280","acquirerMerchantID":"Visa","addrMatch":"N","cardExpiryDate":"2408","acctNumber":"4896780109912655","billAddrCity":null,"billAddrCountry":null,"billAddrLine1":null,"billAddrLine2":null,"billAddrLine3":null,"billAddrPostCode":null,"billAddrSta
te":null,"email":null,"homePhone":{"cc":"1","subscriber":"123"},"mobilePhone":{"cc":"1","subscriber":"123"}},"authenticationResponse":{"threeDSServerTransID":"a009a157-8554-4605-855d-e83fa65d49e9","acsTransID":"7686f23e-cdbb-41ed-b1b3-98a1c9fd3050","acsReferenceNumber":"
3DS_LOA_ACS_201_13579","acsOperatorID":"AcsOpId 4138359541","dsReferenceNumber":"DS186937449533647030","dsTransID":"dd3ae603-c753-499f-876f-f066100b1a6d","sdkTransID":null,"transStatus":"Y","acsChallengeMandated":null,"messageType":"ARes","messageVersion":"2.1.0"},"purch
aseDate":"20220628164132","errorDetails":null,"challengeRequest":null,"base64EncodedChallengeRequest":null}



Browser Challenge

 {"threeDSServerTransID":"e06d0c93-d3d7-4b06-9103-b4b4ed7d8d97","acsURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge","transStatus":"C","authenticationValue":null,"eci":null,"acsChallengeMandated":"Y","authenticationRequest":{"threeDSCompInd":"Y","threeDSRequestorID":"ds-assigned-requestor-id","threeDSRequestorName":"ds-assigned-requestor-name","threeDSRequestorURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method","acquirerBIN":"428280","acquirerMerchantID":"Visa","addrMatch":"N","cardExpiryDate":"2312","acctNumber":"4896780109904462","billAddrCity":null,"billAddrCountry":null,"billAddrLine1":null,"billAddrLine2":null,"billAddrLine3":null,"billAddrPostCode":null,"billAddrState":null,"email":null,"homePhone":{"cc":"1","subscriber":"123"},"mobilePhone":{"cc":"1","subscriber":"123"}},"authenticationResponse":{"threeDSServerTransID":"e06d0c93-d3d7-4b06-9103-b4b4ed7d8d97","acsTransID":"56bb65fc-b7c8-4527-a0f4-298f1fc5327a","acsReferenceNumber":"3DS_LOA_ACS_201_13579","acsOperatorID":"AcsOpId 4138359541","dsReferenceNumber":"DS186937449533647030","dsTransID":"03e8cf25-93d9-4d95-9318-8600386d1a9a","sdkTransID":null,"transStatus":"C","acsChallengeMandated":"Y","messageType":"ARes","messageVersion":"2.1.0"},"purchaseDate":"20220628163415","errorDetails":null,"challengeRequest":{"threeDSServerTransID":"e06d0c93-d3d7-4b06-9103-b4b4ed7d8d97","acsTransID":"56bb65fc-b7c8-4527-a0f4-298f1fc5327a","messageType":"CReq","messageVersion":"2.1.0","challengeWindowSize":"01","messageExtension":null},"base64EncodedChallengeRequest":"eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImUwNmQwYzkzLWQzZDctNGIwNi05MTAzLWI0YjRlZDdkOGQ5NyIsImFjc1RyYW5zSUQiOiI1NmJiNjVmYy1iN2M4LTQ1MjctYTBmNC0yOThmMWZjNTMyN2EiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"}

## Question

I'm call the acs challenge:
https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge

I pass in the payload (which I receive from the Netcetera server as the response for the Authenticate call) :

```json
{
    "base64EncodedChallengeRequest": "eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjRhYjk4NDhhLTgzYmUtNGIwYi05N2ZkLThmMDc1MjdlZjYzOSIsImFjc1RyYW5zSUQiOiI5NTMyMmI1MC03NGM0LTQ1NmQtOTBjOC00YzUxMGVjMTkwMTEiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"
} 
```

My response is:

```json
{"messageType":"Erro","messageVersion":"2.2.0","errorCode":"404","errorComponent":"A","errorDescription":"An unhandled exception occurred","errorDetail":"An unhandled exception occurred. Stack trace is not provided but the error is:com.netcetera.ncacs.crypto.exception.JWEException: Message could not be deserialized.","errorMessageType":"CReq"}
```

and I donot get anything back on the NotificationURL

Here is the  authenticate call I have completed:

```json
{
  "deviceChannel": "02",
  "messageCategory": "01",
  "threeDSCompInd": "Y",
  "threeDSRequestor": {
    "threeDSRequestorAuthenticationInd": "02",
    "threeDSRequestorAuthenticationInfo": {
      "threeDSReqAuthMethod": "04",
      "threeDSReqAuthTimestamp": "201812201735",
      "threeDSReqAuthData": "threeDSReqAuthData"
    },
    "threeDSRequestorChallengeInd": "03",
    "threeDSRequestorPriorAuthenticationInfo": {
      "threeDSReqPriorRef": "VOGXpZvTlCmBUyPnnZfmsGDKqxRsRwPovkAE",
      "threeDSReqPriorAuthMethod": "01",
      "threeDSReqPriorAuthTimestamp": "201812201735",
      "threeDSReqPriorAuthData": "threeDSReqPriorAuthData"
    }
  },
  "cardholderAccount": {
    "acctType": "02",
    "cardExpiryDate": "1812",
    "acctInfo": {
      "chAccAgeInd": "04",
      "chAccDate": "20181220",
      "chAccChangeInd": "03",
      "chAccChange": "20181220",
      "chAccPwChangeInd": "04",
      "chAccPwChange": "20181220",
      "shipAddressUsageInd": "03",
      "shipAddressUsage": "20181220",
      "txnActivityDay": 1,
      "txnActivityYear": 1,
      "provisionAttemptsDay": 1,
      "nbPurchaseAccount": 1,
      "suspiciousAccActivity": "01",
      "shipNameIndicator": "01",
      "paymentAccInd": "03",
      "paymentAccAge": "20181220"
    },
    "shipAddressUsageInd": "03",
    "shipAddressUsage": "20181220",
    "txnActivityDay": 1,
    "txnActivityYear": 1,
    "provisionAttemptsDay": 1,
    "nbPurchaseAccount": 1,
    "suspiciousAccActivity": "01",
    "shipNameIndicator": "01",
    "paymentAccInd": "03",
    "paymentAccAge": "20181220",
    "acctNumber": "4916994064252017",
    "schemeId": "Visa",
    "payTokenInd": true
  },
  "cardholder": {
    "addrMatch": "N",
    "billAddrCity": "Zurich",
    "billAddrCountry": "756",
    "billAddrLine1": "Zypressenstrasse 71",
    "billAddrLine2": "P.O. Box",
    "billAddrLine3": "8040 Zürich",
    "billAddrPostCode": "8000",
    "billAddrState": "CH",
    "email": "netcetera@example.com",
    "homePhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "mobilePhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "workPhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "cardholderName": "John Doe",
    "shipAddrCity": "Zurich",
    "shipAddrCountry": "756",
    "shipAddrLine1": "Zypressenstrasse 98",
    "shipAddrLine2": "P.O. Box",
    "shipAddrLine3": "8040 Zürich",
    "shipAddrPostCode": "8000",
    "shipAddrState": "CH"
  },
  "purchase": {
    "purchaseInstalData": 3,
    "merchantRiskIndicator": {
      "shipIndicator": "01",
      "deliveryTimeframe": "02",
      "deliveryEmailAddress": "netcetera@example.com",
      "reorderItemsInd": "01",
      "preOrderPurchaseInd": "01",
      "preOrderDate": "20181220",
      "giftCardAmount": 2,
      "giftCardCurr": "978",
      "giftCardCount": 1
    },
    "purchaseAmount": 1,
    "purchaseCurrency": "978",
    "purchaseExponent": 1,
    "purchaseDate": "20181220173550",
    "recurringExpiry": "20181220",
    "recurringFrequency": 1,
    "transType": "01"
  },
  "acquirer": {
    "acquirerBin": "428280",
    "acquirerMerchantId": "Visa"
  },
  "merchant": {
    "mcc": "4511",
    "merchantCountryCode": "598",
    "merchantName": "IBE SALES PGK",
    "threeDSRequestorId": "ds-assigned-requestor-id",
    "threeDSRequestorName": "ds-assigned-requestor-name"
  },
  "broadInfo": {"message": "TLS 1.x will be turned off starting summer 2019 "},
  "messageExtension": [
    {
      "name": "name",
      "id": "id",
      "criticalityIndicator": false,
      "data": {
        "valueOne": "value1",
        "valueTwo":"value2"
      }
    }
  ],
  "browserInformation": {
    "browserAcceptHeader": "application/json",
    "browserIP": "192.168.1.11",
    "browserJavaEnabled": true,
    "browserLanguage": "en",
    "browserColorDepth": "8",
    "browserScreenHeight": 1,
    "browserScreenWidth": 1,
    "browserTZ": 1,
    "browserUserAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0",
    "challengeWindowSize": "01"
  }
}

and here is what I received back from the server:
{
    "threeDSServerTransID": "4ab9848a-83be-4b0b-97fd-8f07527ef639",
    "acsURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge",
    "transStatus": "C",
    "authenticationValue": null,
    "eci": null,
    "acsChallengeMandated": "Y",
    "authenticationRequest": {
        "threeDSCompInd": "Y",
        "threeDSRequestorID": "ds-assigned-requestor-id",
        "threeDSRequestorName": "ds-assigned-requestor-name",
        "threeDSRequestorURL": "https://ccpgw.testbsp.com.pg/3dsrequestor",
        "acquirerBIN": "428280",
        "acquirerMerchantID": "Visa",
        "addrMatch": "N",
        "cardExpiryDate": "1812",
        "acctNumber": "4916994064252017",
        "billAddrCity": "Zurich",
        "billAddrCountry": "756",
        "billAddrLine1": "Zypressenstrasse 71",
        "billAddrLine2": "P.O. Box",
        "billAddrLine3": "8040 Zürich",
        "billAddrPostCode": "8000",
        "billAddrState": "CH",
        "email": "netcetera@example.com",
        "homePhone": {
            "cc": "1",
            "subscriber": "123"
        },
        "mobilePhone": {
            "cc": "1",
            "subscriber": "123"
        }
    },
    "authenticationResponse": {
        "threeDSServerTransID": "4ab9848a-83be-4b0b-97fd-8f07527ef639",
        "acsTransID": "95322b50-74c4-456d-90c8-4c510ec19011",
        "acsReferenceNumber": "3DS_LOA_ACS_201_13579",
        "acsOperatorID": "AcsOpId 4138359541",
        "dsReferenceNumber": "DS186937449533647030",
        "dsTransID": "c32ca5bd-1232-45d2-9983-537da587a603",
        "sdkTransID": null,
        "transStatus": "C",
        "acsChallengeMandated": "Y",
        "messageType": "ARes",
        "messageVersion": "2.1.0"
    },
    "purchaseDate": "20181220173550",
    "errorDetails": null,
    "challengeRequest": {
        "threeDSServerTransID": "4ab9848a-83be-4b0b-97fd-8f07527ef639",
        "acsTransID": "95322b50-74c4-456d-90c8-4c510ec19011",
        "messageType": "CReq",
        "messageVersion": "2.1.0",
        "challengeWindowSize": "01",
        "messageExtension": null
    },
    "base64EncodedChallengeRequest": "eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjRhYjk4NDhhLTgzYmUtNGIwYi05N2ZkLThmMDc1MjdlZjYzOSIsImFjc1RyYW5zSUQiOiI5NTMyMmI1MC03NGM0LTQ1NmQtOTBjOC00YzUxMGVjMTkwMTEiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"
}
```

### Response:

From what I can see from the error message:

```json
{"messageType":"Erro","messageVersion":"2.2.0","errorCode":"404","errorComponent":"A","errorDescription":"An unhandled exception occurred","errorDetail":"An unhandled exception occurred. Stack trace is not provided but the error is:com.netcetera.ncacs.crypto.exception.JWEException: Message could not be deserialized.","errorMessageType":"CReq"}
```

it looks like a **PERMANENT_SYSTEM_FAILURE("404")** error on the ACS ( **ACCESS_CONTROL_SERVER("A")**).



## Question

When calling https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method

with this payload:

```json
{
    "threeDSServerTransID": "655698f5-01bc-4dc4-bfdb-3140024b8c0c",
    "threeDSMethodNotificationURL": "https://ccpgw.testbsp.com.pg/3dsmethodnotification"
}
```

but my response is: 

```json
{
    "timestamp": "2022-06-06T03:20:51.922+00:00",
    "status": 415,
    "error": "Unsupported Media Type",
    "path": "/acs/3ds-method"
}
```

### Response:

You can simulate this directly with the browser as well, but you should create a form like in the initial reply: 

```html
<form name="frm" method="POST" action="https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method"> 
     <input type="hidden" name="threeDSMethodData" value="eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjNhYzdjYWE3LWFhNDItMjY2My03OTFiLTJhYzA1YTU0MmM0YSIsInRocmVlRFNNZXRob2ROb3RpZmljYXRpb25VUkwiOiJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIn0"> 
</form> 
```

 This way, the ACS will receive the threeDSMethodNotificationURL and the threeDSServerTransID and it should respond with only the threeDSServerTransID in encoded format. Let us know if this works and how to proceed. 



From the Versioning, we get the following response:

```json
{
    "threeDSServerTransID": "8f954d74-744f-4d21-acba-c139184b3251",
    "acsStartProtocolVersion": "2.1.0",
    "acsEndProtocolVersion": "2.2.0",
    "dsStartProtocolVersion": "2.1.0",
    "dsEndProtocolVersion": "2.2.0",
    "highestCommonSupportedProtocolVersion": "2.2.0",
    "acsInfoInd": null,
    "threeDSMethodURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method",
    "threeDSMethodDataForm": {
        "threeDSMethodData": "eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly8zZHNzLnByZXYubmV0Y2V0ZXJhLXBheW1lbnQuY2gvM2RzLXNlcnZlci8zZHMvM2RzLW1ldGhvZC1ub3RpZmljYXRpb24iLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjhmOTU0ZDc0LTc0NGYtNGQyMS1hY2JhLWMxMzkxODRiMzI1MSJ9"
    },
    "threeDSMethodData": {
        "threeDSMethodNotificationURL": "https://3dss.prev.netcetera-payment.ch/3ds-server/3ds/3ds-method-notification",
        "threeDSServerTransID": "8f954d74-744f-4d21-acba-c139184b3251"
    },
    "errorDetails": null
}
```



Now we can take the threeDSMethodData in its base 64 encoded format and we should pass it as form parameter to the threeDSMethodURL. In postman, we can do that with the 
x-www-form-urlencoded type of request, since this will simulate request coming from the browser, please check the image in attachments.

![](images/Netcetera-tdsMethod.png)





## Question 1:

I need some help with the 3DS v2.x setup. I have successfully submitted the 3DS-Versioning-Request and received the response:

```json
{
"threeDSServerTransID": "355cdf9c-1b1e-420e-a74e-feeff72467f1",
"acsStartProtocolVersion": "2.1.0",
"acsEndProtocolVersion": "2.2.0",
"dsStartProtocolVersion": "2.1.0",
"dsEndProtocolVersion": "2.2.0",
"highestCommonSupportedProtocolVersion": "2.2.0",
"acsInfoInd": null,
"threeDSMethodURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method",
"threeDSMethodDataForm": {
"threeDSMethodData": "eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9leGFtcGxlLmNvbS8zZHMtbWV0aG9kLW5vdGlmaWNhdGlvbi11cmwiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjM1NWNkZjljLTFiMWUtNDIwZS1hNzRlLWZlZWZmNzI0NjdmMSJ9"
},
"threeDSMethodData": {
"threeDSMethodNotificationURL": "https://example.com/3ds-method-notification-url",
"threeDSServerTransID": "355cdf9c-1b1e-420e-a74e-feeff72467f1"
},
"errorDetails": null
}
```

As I understand, I now redirect the user to the ACS/3DS-Method-URL (i.e. "threeDSMethodURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method") This triggers device data collection on ACS and then ACS sends results to back on the Notification URL that I set in the Netcetera 3DS server admin. Is this correct?

```
You are mostly correct, except the redirection of the user. The user shouldn't be concerned with the threeDSMethod data, but we do this before we initiate the Areq to the 3DS server, without the knowledge of the cardholder. Also, the result of the threeDSMethod will be returned on the Three DS Method Notification URL, not the Notification URL where the result of the challenge is returned.
```



## Question2 : 

What format are the results coming back from the ACS to the Notification URL? What results am I to expect from the ACS? Will it be JSON?

```
During the challenge procedure, the result of the challenge will be returned to the Notification URL. It will be in the form of the RReq/RRes in JSON format from your latest update. For example, if the transaction is challenged, we will have the following response in a form of ARes:
```

```json
"authenticationResponse": {
"messageType": "ARes",
"threeDSServerTransID": "bdc5b276-c8c5-41f8-85f1-a276c204d05a",
"acsTransID": "544f62c4-ce35-4a61-bbaa-c413abe45bc1",
"acsReferenceNumber": "3DS_LOA_ACS_201_13579",
"acsOperatorID": "AcsOpId 4138359541",
"acsURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge",
"authenticationType": "02",
"acsChallengeMandated": "Y",
"dsReferenceNumber": "DS186937449533647030",
"dsTransID": "c6ada28b-d0ad-4c2b-9540-57b78825b456",
"messageVersion": "2.1.0",
"transStatus": "C",
"transStatusReason": "15",
"broadInfo": {
"message": "TLS 1.x will be turned off starting summer 2019 "
}
},
,*******
"base64EncodedChallengeRequest": "eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImJkYzViMjc2LWM4YzUtNDFmOC04NWYxLWEyNzZjMjA0ZDA1YSIsImFjc1RyYW5zSUQiOiI1NDRmNjJjNC1jZTM1LTRhNjEtYmJhYS1jNDEzYWJlNDViYzEiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"
}
```

The trans status C, indicates that the transaction is challenged and in this case we will need to send the challenge request to the ACS URL which will also be in the ARes so we initate the challenge process. Once it is done, the result of this procedure will be retuned to the Notification URL in the form of the RReq.



## Question 3 : 

Can the Notification URL be a RestFul web service? What will the payload be?

- Correct, the notification URL should be a restful web service, and its payload will be in the form of RRes/RReq or an error message in case there
was an issue with the challenge procedure, you can see examples of this on the following link, they are the ones from your latest update:
https://3dsserver.netcetera.com/3dsserver-saas/doc/2.5.2.0/3ds-results



## Question 4 : 

When I redirect the user to the ACS/3DS-Method-URL do I just send the URL (https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method) or is there any additional information I need to attach?

- You need to redirect the user to the ACS only in case of challenge transaction.
If you want to handle the method data, you will send the following info to the 3DS method URL (Also from the acs, but user is not redirected here):

### Decoded threeDSMethodData:

```json
{
    "threeDSServerTransID":"3ac7caa7-aa42-2663-791b-2ac05a542c4a",
    "threeDSMethodNotificationURL":"threeDSMethodNotificationURL"
}
```

And you should expect the following **<u>response:</u>**

### Decoded threeDSMethodData:

```json
{
	"threeDSServerTransID":"3ac7caa7-aa42-2663-791b-2ac05a542c4a"
}
```



Once you receive the response, you need to set the 'threeDSCompInd' parameter in the AReq to Y. If the threeDSmethod didn't complete, you set
the threeDSCompInd to N, or if the card range doesn't have threeDSMethodURL returned during versioning, you see it to U and start the AReq. Usually
the timeout for this procedure is 10 seconds.

Please note that this is optional step, you can simply ignore the whole threeDSMethod data step and set the threeDSCompInd directly to U for each
transaction, and it shouldn't affect the traffic. This step is used, so the ACS will gather browser info of the cardholder and might provide positive response to the transaction during its Risk assessment, without challenge.



You can find details in the EMV 3-D Secure Protocol and Core Functions Specification v2.2.0 document, A.5.3 3DS Method Data section.
https://www.emvco.com/emv-technologies/3d-secure/

