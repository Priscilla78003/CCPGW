/*
 * ***************************************************************
 * Truteq Internet Payment Gateway (IPGW) version 1.0.0
 * ***************************************************************
 * Copyright (c) 2021 Truteq Australia 2019
 * ***************************************************************
 * IPGW Postilion Adapter: POSTILION - Transaction Manager Adapter 
 * Support: Grant O'Reilly gbo@truteq.com
 * V01.00.00  14-Apr-2021 
 * ***************************************************************
 */
package com.truteq.ccpgw.adapter.postilion.requests;

import com.truteq.ccpgw.adapter.postilion.requests.element.interfaces.Elements;
import com.truteq.ccpgw.adapter.postilion.requests.objects.AuthoriseObject;
import com.truteq.ccpgw.communication.server.logging.wrapper.LogWrapper;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;

/**
 *
 * @author Grant Blaise O'Reilly <gbo@truteq.com>
 */
public class Authorisation extends PostilionRequest {

    private final LogWrapper mLogger = new LogWrapper(Authorisation.class);
    private final AuthoriseObject authoriseObj;

    public Authorisation(ISOPackager vISOPackager, AuthoriseObject authObj) {
        super(vISOPackager);
        this.authoriseObj = authObj;
    }

    private String toBinary(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * Byte.SIZE);
        for (int i = 0; i < Byte.SIZE * bytes.length; i++) {
            sb.append((bytes[i / Byte.SIZE] << i % Byte.SIZE & 0x80) == 0 ? '0' : '1');
        }
        return sb.toString();
    }

    private String bytesToHex(byte[] bytes) {
        String[] arr = new String[bytes.length];
        for (int i = 0; i < bytes.length; i++) {
            arr[i] = arr[i] = String.format("%02x", Byte.parseByte(bytes[i] + ""));
        }
        return java.util.Arrays.toString(arr);
    }
    
    @Override
    public ISOMsg getUnpacked() throws com.truteq.protocol.MessageException {

        try {
            ISOMsg vISOMsg = new ISOMsg();
            vISOMsg.setPackager(this.getvISOPackager());
            vISOMsg.setMTI(this.getAuthoriseObj().getMessageType());
            vISOMsg.set(Elements.TRANSMISSION_DATE_TIME, this.getAuthoriseObj().getTransmissionDateTime());  //DE7
            vISOMsg.set(Elements.SYSTEM_TRACE_AUDIT_NUMBER, this.getAuthoriseObj().getSystemTraceAuditNumber()); //DE11
            vISOMsg.set(Elements.LOCAL_TRAN_DATE, this.getAuthoriseObj().getLocalTranDate()); //DE13
            vISOMsg.set(Elements.LOCAL_TRAN_TIME, this.getAuthoriseObj().getLocalTranTime());  //DE12

            vISOMsg.set(Elements.PRIMARY_ACCOUNT_NUMBER, this.getAuthoriseObj().getPrimaryAccountNumber()); //DE2
            vISOMsg.set(Elements.PROCESSING_CODE, this.getAuthoriseObj().getProcessingCode());   //DE3
            vISOMsg.set(Elements.AMOUNT, this.getAuthoriseObj().getTransactionAmount());         //DE4
            vISOMsg.set(Elements.EXPIRATION_DATE, this.getAuthoriseObj().getAccountExpiryDate());       //DE14
            vISOMsg.set(Elements.MERCHANT_TYPE, this.getAuthoriseObj().getMerchantType());             //DE18
            vISOMsg.set(Elements.POS_ENTRY_MODE, this.getAuthoriseObj().getPosEntryMode());             //DE22
            vISOMsg.set(Elements.POS_CONDITION_CODE, this.getAuthoriseObj().getPosConditionCode());     //DE25
            vISOMsg.set(Elements.AQC_INSTITUDE_ID_CODE, this.getAuthoriseObj().getAcquiringInstitutionCode());//DE32
            vISOMsg.set(Elements.CARD_ACCEPT_TERMINAL_ID, this.getAuthoriseObj().getTerminalId());           //DE41
            vISOMsg.set(Elements.CARD_ACCEPT_ID_CODE, this.getAuthoriseObj().getMerchantId());               //DE42
            vISOMsg.set(Elements.CARD_ACCEPT_NAME_LOC, this.getAuthoriseObj().getCardAcceptorNameLocation());//DE43
            vISOMsg.set(Elements.CURRENCY_CODE, this.getAuthoriseObj().getCurrencyCodeTransaction());   //DE49
            vISOMsg.set(Elements.POS_DATA_CODE, this.getAuthoriseObj().getPosDataCode());               //DE123

            if (this.getAuthoriseObj().getField127() != null) {
                ISOMsg f127 = new ISOMsg(127);
                f127.setPackager(this.getvISOPackager());
                f127.set(10, this.getAuthoriseObj().getField127().getCvv2());

                if (this.getAuthoriseObj().getField127().getAddressVerificationData() != null) {
                    if (!this.getAuthoriseObj().getField127().getAddressVerificationData().equals("")) {
                        f127.set(15, this.getAuthoriseObj().getField127().getAddressVerificationData());
                    }
                }
                if (this.getAuthoriseObj().getField127().getCardVerificationData() != null) {
                    if (!this.getAuthoriseObj().getField127().getCardVerificationData().equals("")) {
                        f127.set(27, this.getAuthoriseObj().getField127().getCardVerificationData());
                    }
                }

                if (this.getAuthoriseObj().getField127().getThreeDSecureData() != null) {
                    f127.set(29, this.getAuthoriseObj().getField127().getThreeDSecureData());
                }

                if (this.getAuthoriseObj().getField127().getThreeDSecureResult() != null) {
                    if (!this.getAuthoriseObj().getField127().getThreeDSecureResult().equals("")) {
                        f127.set(30, this.getAuthoriseObj().getField127().getThreeDSecureResult());
                    }
                }

                if (this.getAuthoriseObj().getField127().getUcafData() != null) {
                    f127.set(32, this.getAuthoriseObj().getField127().getUcafData());
                }
                
                if (this.getAuthoriseObj().getField127().getStructuredData() != null) {
                   f127.set(22,this.getAuthoriseObj().getField127().getStructuredData()); 
                }
                

                vISOMsg.set(f127);
            }

            return vISOMsg;

        } catch (ISOException vException) {
            mLogger.error(vException.getMessage() + vException, new Throwable().getStackTrace()[0]);
            throw new com.truteq.protocol.MessageException(vException.getMessage());
        }

    }

    public ISOMsg generateAuthoriseResponse(String responseCode) {
        try {
            ISOMsg vISOMsg = new ISOMsg();
            vISOMsg.setPackager(this.getvISOPackager());
            vISOMsg.setMTI("PP0110");

            vISOMsg.setPackager(this.getvISOPackager());
            vISOMsg.setMTI(this.getAuthoriseObj().getMessageType());
            vISOMsg.set(Elements.TRANSMISSION_DATE_TIME, this.getAuthoriseObj().getTransmissionDateTime());  //DE7
            vISOMsg.set(Elements.SYSTEM_TRACE_AUDIT_NUMBER, this.getAuthoriseObj().getSystemTraceAuditNumber()); //DE11
            vISOMsg.set(Elements.LOCAL_TRAN_DATE, this.getAuthoriseObj().getLocalTranDate()); //DE13
            vISOMsg.set(Elements.LOCAL_TRAN_TIME, this.getAuthoriseObj().getLocalTranTime());  //DE12

            vISOMsg.set(Elements.PRIMARY_ACCOUNT_NUMBER, this.getAuthoriseObj().getPrimaryAccountNumber()); //DE2
            vISOMsg.set(Elements.PROCESSING_CODE, this.getAuthoriseObj().getProcessingCode());   //DE3
            vISOMsg.set(Elements.AMOUNT, this.getAuthoriseObj().getTransactionAmount());         //DE4
            vISOMsg.set(Elements.EXPIRATION_DATE, this.getAuthoriseObj().getAccountExpiryDate());       //DE14
            vISOMsg.set(Elements.MERCHANT_TYPE, this.getAuthoriseObj().getMerchantType());             //DE18
            vISOMsg.set(Elements.POS_ENTRY_MODE, this.getAuthoriseObj().getPosEntryMode());             //DE22
            vISOMsg.set(Elements.POS_CONDITION_CODE, this.getAuthoriseObj().getPosConditionCode());     //DE25
            vISOMsg.set(Elements.AQC_INSTITUDE_ID_CODE, this.getAuthoriseObj().getAcquiringInstitutionCode());//DE32
            vISOMsg.set(Elements.CARD_ACCEPT_TERMINAL_ID, this.getAuthoriseObj().getTerminalId());           //DE41
            vISOMsg.set(Elements.CARD_ACCEPT_ID_CODE, this.getAuthoriseObj().getMerchantId());               //DE42
            vISOMsg.set(Elements.CARD_ACCEPT_NAME_LOC, this.getAuthoriseObj().getCardAcceptorNameLocation());//DE43
            vISOMsg.set(Elements.CURRENCY_CODE, this.getAuthoriseObj().getCurrencyCodeTransaction());   //DE49
            vISOMsg.set(Elements.POS_DATA_CODE, this.getAuthoriseObj().getPosDataCode());               //DE123

            if (this.getAuthoriseObj().getField127() != null) {
                ISOMsg f127 = new ISOMsg(127);
                f127.setPackager(this.getvISOPackager());
                f127.set(10, this.getAuthoriseObj().getField127().getCvv2());

                if (this.getAuthoriseObj().getField127().getAddressVerificationData() != null) {
                    if (!this.getAuthoriseObj().getField127().getAddressVerificationData().equals("")) {
                        f127.set(15, this.getAuthoriseObj().getField127().getAddressVerificationData());
                    }
                }
                if (this.getAuthoriseObj().getField127().getCardVerificationData() != null) {
                    if (!this.getAuthoriseObj().getField127().getCardVerificationData().equals("")) {
                        f127.set(27, this.getAuthoriseObj().getField127().getCardVerificationData());
                    }
                }

                if (this.getAuthoriseObj().getField127().getThreeDSecureData() != null) {
                    f127.set(29, this.getAuthoriseObj().getField127().getThreeDSecureData());
                }

                if (this.getAuthoriseObj().getField127().getThreeDSecureResult() != null) {
                    if (!this.getAuthoriseObj().getField127().getThreeDSecureResult().equals("")) {
                        f127.set(30, this.getAuthoriseObj().getField127().getThreeDSecureResult());
                    }
                }

                if (this.getAuthoriseObj().getField127().getUcafData() != null) {
                    f127.set(32, this.getAuthoriseObj().getField127().getUcafData());
                }
                
                if (this.getAuthoriseObj().getField127().getStructuredData() != null) {
                   f127.set(22,this.getAuthoriseObj().getField127().getStructuredData()); 
                }

                vISOMsg.set(f127);
            }

            return vISOMsg;

        } catch (ISOException vException) {
            mLogger.error(vException.getMessage(), vException, new Throwable().getStackTrace()[0]);
        }
        return null;
    }

    /**
     * @return the authoriseObj
     */
    public AuthoriseObject getAuthoriseObj() {
        return authoriseObj;
    }

}
