 

![](../headerImages//PlatformPAC.png)



# 3DS 2.x Sabre Integration 

###### version: 1.0.0

<img align="left" width="100" height="120" src="../headerImages/GrantOReilly.png"/>

Author: <span style="color:blue">**Grant Blaise O'Reilly PhD.**</span>

###### **Java Developer and System Architect**

email: grant@platformpac.com.pg



## Introduction

This document covers the integration of the 3DS 2.x using the Netcetera 3DSServer into the Sabre Frontend Adapter i.e. Sabre integration of 3DS v2.x.







## One-step 3DS 2.x flow from Sabre

###### Method 1a: Dynamic 3DS (Preferred Method)

Below are steps in this flow:

1. Sabre sends AuthRQ to BSP
2. BSP sends 3DS-Versioning-Request to your MPI provider, identifies version and sends a URL to Sabre. (In case of 3DS2, this URL would be BSP’s own URL)
3. Sabre redirects user to BSP URL. Sabre will include its return URLs in this redirection.
4. BSP redirects user to ACS/3DS-Method-URL received from the earlier 3DS-Versioning-Request. This triggers device data collection and then ACS sends results to BSP.
5. BSP then sends the Authentication-Request.
6. If response from ACS indicates a challenge is needed, BSP redirects user to the ACS-challenge-URL.
7. After challenge is completed, ACS returns results to BSP. (BSP will need to facilitate possible multiple challenges)
8. BSP continues with payment authorization
9. BSP then redirects user back to Sabre page.
10. Sabre redirects user to POS page.
11. BSP also sends a server-to-server notification to Sabre.

Sequence diagram for this flow is listed below. (POS is Point-Of-Sale application, SEPG is Sabre Enterprise Payment Gateway, Vendor is BSP)

![](images/Sabre-3DSv2.x-OneStep.png)

## Two-step 3DS 2.x flow from Sabre

###### Method 1b: Dynamic 3DS (Alternative Flow)

The same can be accomplished with Method 1b listed in Section 3.2.2. We call this flow as the 2-step flow. (2 AuthRQ requests sent to BSP)

Below are steps in this flow:

1. Sabre sends AuthRQ to BSP
2. BSP sends 3DS-Versioning-Request to your MPI provider, identifies version and sends a URL to Sabre.
     (In case of 3DS2, this URL would be BSP’s own URL)
3. Sabre redirects user to BSP URL. Sabre will include its return URLs in this redirection.
4. BSP redirects user to ACS/3DS-Method-URL received from the earlier 3DS-Versioning-Request. This triggers device data collection and then ACS sends results to BSP.
5. BSP then sends the Authentication-Request.
6. If response from ACS indicates a challenge is needed, BSP redirects user to the ACS-challenge-URL.
7. After challenge is completed, ACS returns results to BSP. (BSP will need to facilitate possible multiple challenges)
8. BSP then redirects user back to Sabre page and includes the challenge response (Cres / PaRes)
9. Sabre sends the second AuthRQ request to BSP including challenge response (Cres / PaRes)
10. BSP processes authorization and sends outcome to Sabre
11.Sabre redirects user to POS page.

Sequence diagram for this flow is listed below. (POS is Point-Of-Sale application, SEPG is Sabre Enterprise Payment Gateway, Vendor is BSP)

 ![](images/Sabre-3DSv2.x-TwoStep.png)



| Step | One Step  3DSv2.x                                            | Two Step 3DSv2.x                                             |
| ---- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| 1    | SEPG receives payment request from IBE (Internet Booking Engine). | SEPG receives payment request from IBE (Internet Booking Engine). |
| 2    | SEPG sends Auth request to PSP.                              | SEPG sends Auth request to PSP.                              |
| 3    | PSP determines if payer authentication is required. This can either be a simple enrollment verification or based on merchant configurable business rules (such as whitelist) | PSP determines if payer authentication is required. This can either be a simple enrollment verification or based on merchant configurable business rules (such as whitelist) |
| 4    | If payer authentication is required, PSP has the option to choose either one of the following options: a. PSP returns IssuerURL for shopper redirection including optional PAReq, TermURL and MD. b. PSP creates and returns a HTML form for browser redirection. | If payer authentication is required, PSP returns IssuerURL, PAReq and MD. In this method, the IssuerURL is the issuer bank URL. |
| 5    | Depending on Step 4, SEPG either creates the HTML form (in case of Step 4a) or simply returns the HTML form received from PSP (in case of Step 4b) to IBE for browser redirection. In either case, the form should contain the following fields: | SEPG creates and returns HTML form (containing SEPG-Result-URL) for redirection to IBE. |
| 6    | Using the HTML form received from SEPG, IBE then redirects shopper to issuer bank for authentication. (Depending on the HTML form, the shopper is either redirected straight to the bank page or redirected to PSP first and then to the bank.) | IBE redirects cardholder to issuer bank site.                |
| 7    | Issuer bank authenticates shopper and redirects shopper to PSP. | Issuer bank authenticates cardholder and redirects cardholder to SEPG-Result-URL with PARes. |
| 8    | PSP processes auth based on PARes and redirects cardholder to SEPG via HTTP GET (using Return URL specified in AuthRQ), containing the following fields: | SEPG sends 3DS Auth to PSP with PARes and MD.                |
| 9    | Additionally, PSP also sends a server-to-server notification to SEPG via HTTP POST containing the following fields as applicable (see figure) PSP should continue sending this notification periodically until a “[OK]” message is received as an indication that the notification has been received and processed successfully by SEPG. | PSP processes Auth request and returns result to SEPG.       |
| 10   | SEPG redirects cardholder to IBE with auth result.           | SEPG redirects cardholder to IBE with auth result.           |
|      |                                                              |                                                              |

![](images/OneStep-step5.png)



![](images/OneStep-step8.png)



![](images/OneStep-step9.png)

## Netcetera current 3DS 2.x offering

![](drawio/SequenceDiagram.drawio.svg)
