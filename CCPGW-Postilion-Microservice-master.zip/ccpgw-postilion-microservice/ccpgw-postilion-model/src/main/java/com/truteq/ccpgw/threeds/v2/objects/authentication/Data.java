/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.truteq.ccpgw.threeds.v2.objects.authentication;

/**
 *
 * @author Grant Blaise O'Reilly <gbo@truteq.com>
 */

public class Data {
   private String valueOne;
   private String ValueTwo;

    /**
     * @return the valueOne
     */
    public String getValueOne() {
        return valueOne;
    }

    /**
     * @param valueOne the valueOne to set
     */
    public void setValueOne(String valueOne) {
        this.valueOne = valueOne;
    }

    /**
     * @return the ValueTwo
     */
    public String getValueTwo() {
        return ValueTwo;
    }

    /**
     * @param ValueTwo the ValueTwo to set
     */
    public void setValueTwo(String ValueTwo) {
        this.ValueTwo = ValueTwo;
    }
       
}
