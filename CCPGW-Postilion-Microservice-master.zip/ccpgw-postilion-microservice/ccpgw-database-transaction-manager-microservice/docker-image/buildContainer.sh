sudo docker build -t microservice-ccpgw-transaction-manager-1.22.0 .
