 

http://grantserver:8083/

![](assets/images/Screenshot_20230124_132201.png)

![](assets/images/Screenshot_20230124_132805.png)

![](assets/images/Screenshot_20230124_133007.png)

![](assets/images/Screenshot_20230124_133122.png)



Configure Woocommerce

```
username: admin
password: admin
```



![](assets/images/Screenshot_20230124_133159.png)

![](assets/images/Screenshot_20230124_133506.png)

dc3c62ee4d349a6cda7edd11e5972ec2f16e7e5b4444826c774e59d0af3b0574

https://ccpgw.testbsp.com.pg/keycloak/ccpgw/authenticate/authorise/order/payment





