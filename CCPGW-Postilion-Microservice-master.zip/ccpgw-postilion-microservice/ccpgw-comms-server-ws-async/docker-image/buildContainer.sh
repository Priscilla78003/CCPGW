sudo docker build -t microservice-ccpgw-comms-server-ws-async-1.6.0 .
