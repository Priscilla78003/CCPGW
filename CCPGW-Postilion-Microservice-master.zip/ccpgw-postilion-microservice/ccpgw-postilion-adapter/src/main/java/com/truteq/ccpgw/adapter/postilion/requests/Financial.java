/*
 * ***************************************************************
 * Truteq Internet Payment Gateway (IPGW) version 1.0.0
 * ***************************************************************
 * Copyright (c) 2021 Truteq Australia 2019
 * ***************************************************************
 * IPGW Postilion Adapter: POSTILION - Transaction Manager Adapter 
 * Support: Grant O'Reilly gbo@truteq.com
 * V01.00.00  14-Apr-2021 
 * ***************************************************************
 */
package com.truteq.ccpgw.adapter.postilion.requests;

import com.truteq.ccpgw.adapter.postilion.enums.eAuth;
import com.truteq.ccpgw.adapter.postilion.requests.element.interfaces.Elements;
import com.truteq.ccpgw.adapter.postilion.requests.objects.AuthoriseObject;
import com.truteq.ccpgw.communication.server.logging.wrapper.LogWrapper;
import com.truteq.protocol.MessageException;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;

/**
 *
 * @author Grant Blaise O'Reilly <gbo@truteq.com>
 */
public class Financial extends PostilionRequest{
    
    private final LogWrapper mLogger = new LogWrapper(Financial.class);
    private final AuthoriseObject authoriseObj;

    public Financial (ISOPackager vISOPackager, AuthoriseObject authObj) {
        super(vISOPackager);
        this.authoriseObj = authObj;
        
    }

    @Override
    public ISOMsg getUnpacked() throws MessageException {
        try {
            ISOMsg vISOMsg = new ISOMsg();
            vISOMsg.setPackager(this.getvISOPackager());
            vISOMsg.setMTI(this.getAuthoriseObj().getMessageType());
            vISOMsg.set(Elements.TRANSMISSION_DATE_TIME,this.getAuthoriseObj().getTransmissionDateTime());
            vISOMsg.set(Elements.SYSTEM_TRACE_AUDIT_NUMBER,this.getAuthoriseObj().getSystemTraceAuditNumber());
            vISOMsg.set(Elements.LOCAL_TRAN_DATE,this.getAuthoriseObj().getLocalTranDate());
            vISOMsg.set(Elements.LOCAL_TRAN_TIME,this.getAuthoriseObj().getLocalTranTime()); 
            
            vISOMsg.set(Elements.PRIMARY_ACCOUNT_NUMBER,this.getAuthoriseObj().getPrimaryAccountNumber());
            vISOMsg.set(Elements.PROCESSING_CODE,this.getAuthoriseObj().getProcessingCode());
            vISOMsg.set(Elements.AMOUNT,this.getAuthoriseObj().getTransactionAmount());
            vISOMsg.set(Elements.EXPIRATION_DATE,this.getAuthoriseObj().getAccountExpiryDate());       //DE14
            vISOMsg.set(Elements.MERCHANT_TYPE ,this.getAuthoriseObj().getMerchantType());             //DE18
            vISOMsg.set(Elements.POS_ENTRY_MODE,this.getAuthoriseObj().getPosEntryMode());             //DE22
            vISOMsg.set(Elements.POS_CONDITION_CODE,this.getAuthoriseObj().getPosConditionCode());     //DE25
            vISOMsg.set(Elements.CARD_ACCEPT_TERMINAL_ID,this.getAuthoriseObj().getTerminalId());           //DE41
            vISOMsg.set(Elements.CARD_ACCEPT_ID_CODE,this.getAuthoriseObj().getMerchantId());               //DE42
            vISOMsg.set(Elements.CARD_ACCEPT_NAME_LOC,this.getAuthoriseObj().getCardAcceptorNameLocation());//DE43
            vISOMsg.set(Elements.CURRENCY_CODE,this.getAuthoriseObj().getCurrencyCodeTransaction());   //DE49
            vISOMsg.set(Elements.POS_DATA_CODE,this.getAuthoriseObj().getPosDataCode());               //DE123
            
            if ((this.authoriseObj.getAuth() == eAuth.FINANCIAL)||
                (this.authoriseObj.getAuth() == eAuth.MOTO)){    

                    ISOMsg f127 = new ISOMsg(127);
                    f127.setPackager(this.getvISOPackager());
                    f127.set(10, this.getAuthoriseObj().getField127().getCvv2()); //DE127.10
                    vISOMsg.set(f127);
            }

            return vISOMsg;

        } catch (ISOException vException) {
            mLogger.error(vException.getMessage(), vException, new Throwable().getStackTrace()[0]);
            throw new com.truteq.protocol.MessageException(vException.getMessage());
        }
    }

    public AuthoriseObject getAuthoriseObj() {
        return authoriseObj;
    }
}
