 ## New Netcetera Cloud Payment Platform (PROD)



```
https://acquiring-auth.netcetera-payment.ch/#/account-management

usewrname: goreilly 
password: N3tc3t3r@19690831 
```

```
https://platform-pacific.3dss-admin.prod.netcetera-cloud-payment.ch/
https://acquiring-auth.prod.netcetera-payment.ch/authentication.html
```



Dear Platform Pacific team,

 

Following your onboarding to our Cloud Payment Platform PREV environment in  November 2022, we’re reaching out to you again for your migration to the Cloud Payment Platform PROD environment.

 

As part of this simple and secure migration, we would like to inform you about the details and upcoming steps.

 

The migration to the Cloud Payment Platform PROD starts with onboarding you to the new 3DS Server Cloud Payment Platform PROD environment which  consists of:

 

- **New endpoints for the Cloud Payment Platform PROD environment:**

| **Endpoint** | **URL**                                                      |
| ------------ | ------------------------------------------------------------ |
| API          | https://platform-pacific.3ds-server.prod.netcetera-cloud-payment.ch/ |
| Admin UI     | https://platform-pacific.3dss-admin.prod.netcetera-cloud-payment.ch/ |

 

- **New accounts and credentials for accessing the 3DS Server Admin portal.**

An activation email will be sent to one person from your organization, namely “Grant O'Reilly / [grant@platformpac.com.pg](mailto:grant@platformpac.com.pg)” with admin rights to Netcetera Auth. 
 He will be able to grant Admin UI access to others from your organization. 
 Logging into the Admin UI is now available via a highly secure 2 factor authentication – username/password and the Futurae app.


With this email you already have received all the required information for the usage of the Cloud Payment Platform PROD. 
 Please start testing the Cloud Payment Platform PROD environment and  give us feedback within the next 2 weeks should you encounter unexpected problems.

Otherwise please plan and proceed with the migration on your side until 31st of March 2023.

If the migration from your side has been performed and upon received  confirmation from your side, transaction processing on Payment Platform PROD will be disabled. 
 However, the transaction data will remain accessible via Admin UI on Payment Platform PROD as per data retention policy. 

**FYI:** We haven’t noticed testing activities from your side in the Cloud PREV environment (provided to you middle of November 2022) so far. 
 As such we are highly recommending that you start your migration journey activities.

**Important note:**

All configurations set in the Admin UI on the Payment Platform PROD  (timeouts, URLs, merchants/acquirers configurations, etc.) were migrated on 21.02.2023 to the Admin UI on the Cloud Payment Platform PROD. 
 Therefore, if you have done or you are planning to do any configuration  changes in the current Payment Platform PROD 3DS Server Admin UI after  the migration date mentioned above,
 note that they aren’t synced with the Cloud Payment Platform PROD 3DS Server. 
 Configuration changes performed in the Cloud Payment Platform PROD 3DS  Server Admin UI aren’t synced with the Payment Platform PROD 3DS Server  as well.

**The APIs and all other Netcetera 3DS Server features remain unchanged.**

User management for the 3DS Admin UI is done in Netcetera Auth:
 PREV: https://acquiring-auth.prev.netcetera-payment.ch  
 PROD: https://acquiring-auth.netcetera-payment.ch

More details regarding the onboarding process to the new Cloud Payment  Platform and authentication of the Admin users can be found on: 
 https://3dsserver.netcetera.com/3dsserver-saas/doc/current/cloud-payment-platform 

We would appreciate if you could acknowledge receipt of this e-mail.

Thank you very much.

 

Best regards,

Markus Jessl
