  ![](../headerImages//PlatformPAC.png)



# Netcetera 3DS 2.x Test: Controller  

###### version: 1.0.0

<img align="left" width="100" height="120" src="../headerImages//GrantOReilly.png"/>

Author: <span style="color:blue">**Grant Blaise O'Reilly PhD.**</span>

###### **Java Developer and System Architect**

email: grant@platformpac.com.pg



# ThreeDSV2controller



## Versioning 



```
http://localhost:9078/transaction/manager/3ds/v2/service/versioning
```

**Note:** The call is to the Transaction Manager i.e. http://localhost:9078/transaction/manager/3ds/v2/service/versioning points to the ThreeDSV2controller described below.

#### Body

```json
{
  "cardholderAccountNumber": "4556557955726624",
  "schemeId": "Visa"
}
```
#### Response
```json
{
    "threeDSServerTransID": "0766508a-c519-4db8-85c2-af5db316478d",
    "acsStartProtocolVersion": "2.1.0",
    "acsEndProtocolVersion": "2.2.0",
    "dsStartProtocolVersion": "2.1.0",
    "dsEndProtocolVersion": "2.2.0",
    "highestCommonSupportedProtocolVersion": "2.2.0",
    "acsInfoInd": null,
    "threeDSMethodURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method",
    "threeDSMethodDataForm": {
        "threeDSMethodData": "eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9leGFtcGxlLmNvbS8zZHMtbWV0aG9kLW5vdGlmaWNhdGlvbi11cmwiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjA3NjY1MDhhLWM1MTktNGRiOC04NWMyLWFmNWRiMzE2NDc4ZCJ9"
    },
    "threeDSMethodData": {
        "threeDSMethodNotificationURL": "https://example.com/3ds-method-notification-url",
        "threeDSServerTransID": "0766508a-c519-4db8-85c2-af5db316478d"
    },
    "errorDetails": null
}
```



## Authentication 



```
http://localhost:9078/transaction/manager/3ds/v2/service/authentication
```

#### Body

```json
{
  "deviceChannel": "02",
  "messageCategory": "01",
  "threeDSCompInd": "Y",
  "threeDSRequestor": {
    "threeDSRequestorAuthenticationInd": "02",
    "threeDSRequestorAuthenticationInfo": {
      "threeDSReqAuthMethod": "04",
      "threeDSReqAuthTimestamp": "201812201735",
      "threeDSReqAuthData": "threeDSReqAuthData"
    },
    "threeDSRequestorChallengeInd": "03",
    "threeDSRequestorPriorAuthenticationInfo": {
      "threeDSReqPriorRef": "VOGXpZvTlCmBUyPnnZfmsGDKqxRsRwPovkAE",
      "threeDSReqPriorAuthMethod": "01",
      "threeDSReqPriorAuthTimestamp": "201812201735",
      "threeDSReqPriorAuthData": "threeDSReqPriorAuthData"
    }
  },
  "cardholderAccount": {
    "acctType": "02",
    "cardExpiryDate": "1812",
    "acctInfo": {
      "chAccAgeInd": "04",
      "chAccDate": "20181220",
      "chAccChangeInd": "03",
      "chAccChange": "20181220",
      "chAccPwChangeInd": "04",
      "chAccPwChange": "20181220",
      "shipAddressUsageInd": "03",
      "shipAddressUsage": "20181220",
      "txnActivityDay": 1,
      "txnActivityYear": 1,
      "provisionAttemptsDay": 1,
      "nbPurchaseAccount": 1,
      "suspiciousAccActivity": "01",
      "shipNameIndicator": "01",
      "paymentAccInd": "03",
      "paymentAccAge": "20181220"
    },
    "shipAddressUsageInd": "03",
    "shipAddressUsage": "20181220",
    "txnActivityDay": 1,
    "txnActivityYear": 1,
    "provisionAttemptsDay": 1,
    "nbPurchaseAccount": 1,
    "suspiciousAccActivity": "01",
    "shipNameIndicator": "01",
    "paymentAccInd": "03",
    "paymentAccAge": "20181220",
    "acctNumber": "4916994064252017",
    "schemeId": "Visa",
    "payTokenInd": true
  },
  "cardholder": {
    "addrMatch": "N",
    "billAddrCity": "Zurich",
    "billAddrCountry": "756",
    "billAddrLine1": "Zypressenstrasse 71",
    "billAddrLine2": "P.O. Box",
    "billAddrLine3": "8040 Zürich",
    "billAddrPostCode": "8000",
    "billAddrState": "CH",
    "email": "netcetera@example.com",
    "homePhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "mobilePhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "workPhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "cardholderName": "John Doe",
    "shipAddrCity": "Zurich",
    "shipAddrCountry": "756",
    "shipAddrLine1": "Zypressenstrasse 98",
    "shipAddrLine2": "P.O. Box",
    "shipAddrLine3": "8040 Zürich",
    "shipAddrPostCode": "8000",
    "shipAddrState": "CH"
  },
  "purchase": {
    "purchaseInstalData": 3,
    "merchantRiskIndicator": {
      "shipIndicator": "01",
      "deliveryTimeframe": "02",
      "deliveryEmailAddress": "netcetera@example.com",
      "reorderItemsInd": "01",
      "preOrderPurchaseInd": "01",
      "preOrderDate": "20181220",
      "giftCardAmount": 2,
      "giftCardCurr": "978",
      "giftCardCount": 1
    },
    "purchaseAmount": 1,
    "purchaseCurrency": "978",
    "purchaseExponent": 1,
    "purchaseDate": "20181220173550",
    "recurringExpiry": "20181220",
    "recurringFrequency": 1,
    "transType": "01"
  },
  "acquirer": {
    "acquirerBin": "acq-bin",
    "acquirerMerchantId": "acq-mer-id"
  },
  "merchant": {
    "mcc": "0742",
    "merchantCountryCode": "756",
    "merchantName": "name",
    "threeDSRequestorId": "ds-assigned-requestor-id",
    "threeDSRequestorName": "ds-assigned-requestor-name"
  },
  "broadInfo": {"message": "TLS 1.x will be turned off starting summer 2019 "},
  "messageExtension": [
    {
      "name": "name",
      "id": "id",
      "criticalityIndicator": false,
      "data": {
        "valueOne": "value1",
        "valueTwo":"value2"
      }
    }
  ],
  "browserInformation": {
    "browserAcceptHeader": "application/json",
    "browserIP": "192.168.1.11",
    "browserJavaEnabled": true,
    "browserLanguage": "en",
    "browserColorDepth": "8",
    "browserScreenHeight": 1,
    "browserScreenWidth": 1,
    "browserTZ": 1,
    "browserUserAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0",
    "challengeWindowSize": "01"
  }
}
```

#### Response

```json
{
    "threeDSServerTransID": "479f70cc-88fa-47d7-b27e-c261b8ab7aee",
    "acsURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge",
    "transStatus": "C",
    "authenticationValue": null,
    "eci": null,
    "acsChallengeMandated": "Y",
    "authenticationRequest": {
        "threeDSCompInd": "Y",
        "threeDSRequestorID": "ds-assigned-requestor-id",
        "threeDSRequestorName": "ds-assigned-requestor-name",
        "threeDSRequestorURL": "https://example.com/3ds-requestor-url",
        "acquirerBIN": "acq-bin",
        "acquirerMerchantID": "acq-mer-id",
        "addrMatch": "N",
        "cardExpiryDate": "1812",
        "acctNumber": "4916994064252017",
        "billAddrCity": "Zurich",
        "billAddrCountry": "756",
        "billAddrLine1": "Zypressenstrasse 71",
        "billAddrLine2": "P.O. Box",
        "billAddrLine3": "8040 Zürich",
        "billAddrPostCode": "8000",
        "billAddrState": "CH",
        "email": "netcetera@example.com",
        "homePhone": {
            "cc": "1",
            "subscriber": "123"
        },
        "mobilePhone": {
            "cc": "1",
            "subscriber": "123"
        }
    },
    "authenticationResponse": {
        "threeDSServerTransID": "479f70cc-88fa-47d7-b27e-c261b8ab7aee",
        "acsTransID": "392d48b3-16e9-41ca-8a93-28ad54cfe61b",
        "acsReferenceNumber": "3DS_LOA_ACS_201_13579",
        "acsOperatorID": "AcsOpId 4138359541",
        "dsReferenceNumber": "DS186937449533647030",
        "dsTransID": "7c8a817f-2195-4cf3-b137-9fe0d0de5676",
        "sdkTransID": null,
        "transStatus": "C",
        "acsChallengeMandated": "Y",
        "messageType": "ARes",
        "messageVersion": "2.1.0"
    },
    "purchaseDate": "20181220173550",
    "errorDetails": null,
    "challengeRequest": {
        "threeDSServerTransID": "479f70cc-88fa-47d7-b27e-c261b8ab7aee",
        "acsTransID": "392d48b3-16e9-41ca-8a93-28ad54cfe61b",
        "messageType": "CReq",
        "messageVersion": "2.1.0",
        "challengeWindowSize": "01",
        "messageExtension": null
    },
    "base64EncodedChallengeRequest": "eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjQ3OWY3MGNjLTg4ZmEtNDdkNy1iMjdlLWMyNjFiOGFiN2FlZSIsImFjc1RyYW5zSUQiOiIzOTJkNDhiMy0xNmU5LTQxY2EtOGE5My0yOGFkNTRjZmU2MWIiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"
}
```



# Results response

### Question/Answer

```
Grant's question:

To whom it may concern,
We are currently setting up 3DS v2.x for our Internet Payment Gateway at BSP. The question I have are:
Once we have recieved an Authentication response from the 3DS Server. The 3DSServer will invoke an URL on the PSP after it has received the RReq from the DS. As we are the PSP we will have to provide this URL to received the Results response.
1./ Can this be a URL to a RestFUL web service expecting the Result Response as a JSON payload that we publish?
2./Where do I set the URL value (i.e. in which object in the Authentication request do I set this URL)?

Please see the attached diagram (where I have indicated the step with a red circle) where I need some feedback on the questions.
```

![](images/Netcetera-3DSv2-RRES.png)

```
Netrcetera's answer/response:
The result response (RRes) message is in JSON format and it is sent to the  URL that you set in the AdminUI (please see screenshot) under the  "Result Response Notification URL" filed.

Here is the definition from EMVCo specification:
"Results Response Message (RRes)
The RRes message acknowledges receipt of the RReq message. The message is  sent by the 3DS Server through the DS to the ACS. There is only one RRes message per authentication. The RRes message is present only in an  authentication requiring a Cardholder challenge."

From the latest version, it can be passed in the AReq, as part of the merchant data:
https://3dsserver.netcetera.com/3dsserver-saas/doc/current/schema/merchantData.html

Release notes concerning the change:
https://3dsserver.netcetera.com/3dsserver-saas/doc/current/releasenotes/2.5.1.0.html 
```



#### Process for setting up Result Response

| Admin propereties                                           | Links                                                        |
| ----------------------------------------------------------- | ------------------------------------------------------------ |
| 3DS Server Admin on payment platform Preview environment    | https://3dss-admin.prev.netcetera-payment.ch/admin/          |
| 3DS Server Admin on payment platform Production environment | https://3dss-admin.netcetera-payment.ch/admin/               |
|                                                             | https://platform-pacific.3ds-server.prev.netcetera-cloud-payment.ch/ |
|                                                             | https://acquiring-auth.prev.netcetera-payment.ch/authentication.html |

```
usewrname: goreilly 
password: N3tc3t3r@19690831    

PROD
password: N3tc3t3r@196908

```



## New Netcetera Cloud Payment Platform (PROD)



```
https://acquiring-auth.netcetera-payment.ch/#/account-management

usewrname: goreilly 
password: N3tc3t3r@19690831

https://acquiring-auth.prev.netcetera-payment.ch/authentication.html

```



Dear Platform Pacific team,

 

Following your onboarding to our Cloud Payment Platform PREV environment in  November 2022, we’re reaching out to you again for your migration to the Cloud Payment Platform PROD environment.

 

As part of this simple and secure migration, we would like to inform you about the details and upcoming steps.

 

The migration to the Cloud Payment Platform PROD starts with onboarding you to the new 3DS Server Cloud Payment Platform PROD environment which  consists of:

 

- **New endpoints for the Cloud Payment Platform PROD environment:**

| **Endpoint** | **URL**                                                      |
| ------------ | ------------------------------------------------------------ |
| API          | https://platform-pacific.3ds-server.prod.netcetera-cloud-payment.ch/ |
| Admin UI     | https://platform-pacific.3dss-admin.prod.netcetera-cloud-payment.ch/ |
|              | https://acquiring-auth.prod.netcetera-payment.ch/authentication.html |

 

- **New accounts and credentials for accessing the 3DS Server Admin portal.**

An activation email will be sent to one person from your organization, namely “Grant O'Reilly / [grant@platformpac.com.pg](mailto:grant@platformpac.com.pg)” with admin rights to Netcetera Auth. 
 He will be able to grant Admin UI access to others from your organization. 
 Logging into the Admin UI is now available via a highly secure 2 factor authentication – username/password and the Futurae app.


With this email you already have received all the required information for the usage of the Cloud Payment Platform PROD. 
 Please start testing the Cloud Payment Platform PROD environment and  give us feedback within the next 2 weeks should you encounter unexpected problems.

Otherwise please plan and proceed with the migration on your side until 31st of March 2023.

If the migration from your side has been performed and upon received  confirmation from your side, transaction processing on Payment Platform PROD will be disabled. 
 However, the transaction data will remain accessible via Admin UI on Payment Platform PROD as per data retention policy. 

**FYI:** We haven’t noticed testing activities from your side in the Cloud PREV environment (provided to you middle of November 2022) so far. 
 As such we are highly recommending that you start your migration journey activities.

**Important note:**

All configurations set in the Admin UI on the Payment Platform PROD  (timeouts, URLs, merchants/acquirers configurations, etc.) were migrated on 21.02.2023 to the Admin UI on the Cloud Payment Platform PROD. 
 Therefore, if you have done or you are planning to do any configuration  changes in the current Payment Platform PROD 3DS Server Admin UI after  the migration date mentioned above,
 note that they aren’t synced with the Cloud Payment Platform PROD 3DS Server. 
 Configuration changes performed in the Cloud Payment Platform PROD 3DS  Server Admin UI aren’t synced with the Payment Platform PROD 3DS Server  as well.

**The APIs and all other Netcetera 3DS Server features remain unchanged.**

User management for the 3DS Admin UI is done in Netcetera Auth:
 PREV: https://acquiring-auth.prev.netcetera-payment.ch  
 PROD: https://acquiring-auth.netcetera-payment.ch

More details regarding the onboarding process to the new Cloud Payment  Platform and authentication of the Admin users can be found on: 
 https://3dsserver.netcetera.com/3dsserver-saas/doc/current/cloud-payment-platform 


We would appreciate if you could acknowledge receipt of this e-mail.

Thank you very much.

 

Best regards,

Markus Jessl





## New Netcetera Cloud Payment Platform (PREV)

Dear Platform Pacific team,

 As part of Netcetera’s continuous improvement initiatives we introduced the Netcetera Cloud Payment Platform and are in the process of migrating our services and customers to this new cloud hosted environment since the beginning of 2022.

 So far, over 65% of our Netcetera 3DS Server SaaS customers have been successfully migrated or onboarded to our Cloud Payment Platform, processing millions of transactions monthly.

 By switching to the new Cloud Payment Platform, our cutting-edge service will bring even more benefits to your business.
 •      **Improved performance** 

Higher availability and stability with SLA guaranteed uptime.

•      **Improved scalability** 

Easier scalability and more flexible infrastructure based on performance needs.

•      **Improved security** 

Highly secured PCI 3DS/DSS certified infrastructure and additional 2FA for the 3DS Server Admin UI. 

•      **Better environmental sustainability** 

Hosting on cloud data centre’s which rely on renewable energy resources, making them environmentally friendly.

 

**We are happy to announce that you are now also able to enjoy the great benefits mentioned above by joining our group of customers migrated to the Cloud Payment Platform.**

 As part of this simple and secure migration, we would like to inform you about the details and upcoming steps.

 The migration to the Cloud Payment Platform starts with onboarding you to  the new 3DS Server Cloud Payment Platform PREV environment which  consists of: 

1. **New endpoints for the Cloud Payment Platform PREV environment:**

| **Endpoint** | **URL**                                                      |
| ------------ | ------------------------------------------------------------ |
| API          | https://platform-pacific.3ds-server.prev.netcetera-cloud-payment.ch/ |
| Admin UI     | https://platform-pacific.3dss-admin.prev.netcetera-cloud-payment.ch/ |

2. **New accounts and credentials for accessing the 3DS Server Admin portal.**

An activation email will be sent to one person from your organization, namely “Grant O'Reilly / [grant@platformpac.com.pg](mailto:grant@platformpac.com.pg)” with admin rights to Netcetera Auth. 
 He will be able to grant Admin UI access to others from your organization. 
 Logging into the Admin UI is now available via a highly secure 2 factor authentication – username/password and the Futurae app.

3. **Reusing the already signed certificate from Payment Platform PREV for Cloud Payment Platform PREV**. 
    Please use the existing certificate for access and API requests to the Cloud Payment Platform PREV.

With this email you already have received all the required information for the usage of the Cloud Payment Platform PREV and can start using it.

1. Please perform testing on the Cloud Payment Platform PREV environment in the following period and give us your feedback.
2. In January 2023 we will setup proactively the Cloud Payment Platform PROD  environment for you and provide you the related endpoints, 
    certificate information, access, etc. as well. This results in both PROD Payment Platforms (Cloud and non-Cloud) being live for you to start  your PROD migration.

To address possible questions on your side, please kindly have a look at the following FAQs.

| **Question**                                                 | **Answer**                                                   |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| Will configurations in my current Payment Platform 3DS Server Admin UI will be automatically migrated to the Cloud Payment Platform 3DS Server Admin UI? | All configurations done in the current Payment Platform PREV 3DS Server Admin UI (timeouts and URLs, any merchants/acquirers configurations, etc.) were already migrated on 10th of  November 2022 to the Cloud Payment Platform PREV 3DS Server Admin UI.  Therefore, if you have done or you are planning to do any configuration  changes in the current Payment Platform PREV 3DS Server Admin UI after the date mentioned above, note that they aren’t  synced with the Cloud Payment Platform PREV 3DS Server. Configuration  changes performed in the Cloud Payment Platform PREV 3DS Server Admin UI aren’t synced with the Payment Platform PREV 3DS Server as well. The approach for the Cloud Payment Platform PROD  will be the same. |
| What will happen to my current Payment Platform access and data once I’m onboarded to Cloud Payment Platform? | Your current Payment Platform access will stay fully enabled until your  migration to Cloud Payment Platform PROD is finished. Afterwards transaction processing on the Payment Platform will be  disabled. However, your transaction data will remain accessible via the  Admin UI on Payment Platform as per data retention policy. |
| Is the Cloud Payment Platform 3DS Server fully backward compatible to the Payment Platform 3DS Server? | Yes, the APIs and all other current Netcetera 3DS Server features remain unchanged. **New features or enhancements might be only made available on the Cloud Payment Platform.** |
| Does Netcetera need to be informed if my IP addresses from which requests  are send towards the Cloud Payment Platform 3DS Server, are changing? | No, IP address whitelisting is no longer be required on the Cloud Payment Platform. |
| Does the migration to the Cloud Payment Platform require or result in any changes of the current contractual documents? | No, the current signed contractual documents already cover Netcetera’s Cloud Payment Platform. |

More details regarding the onboarding process to the new Cloud Payment Platform and authentication of the Admin users can be found at: 

https://3dss.netcetera.com/3dsserver-saas/doc/current/cloud-payment-platform



## Logging onto the Netcetera Cloud Payment Platform (PREV)

```
https://acquiring-auth.prev.netcetera-payment.ch/authentication.html

```



```
New PREV

username: goreilly 
password: N3tc3t3r@196908
```

```
https://platform-pacific.3dss-admin.prev.netcetera-cloud-payment.ch/
```

![](images/CloudPrev-OAuth2.png)

**Note: this must be clicked.**

![](images/CloudPrev.png)





The result response (RRes) message is in JSON format and it is sent to the URL that you set in the AdminUI (please see diagram below) under the "Result Response Notification URL" filed.

##### Results Response Message (RRes) definition from EMVCo specification:

The RRes message acknowledges receipt of the RReq message. The message is sent by the 3DS Server through the DS to the ACS. There is only one RRes message per authentication. The RRes message is present only in an authentication requiring a Cardholder challenge.

From the latest version, it can be passed in the AReq, as part of the  [merchant data](#MerchantData)

Release notes concerning the change:
https://3dsserver.netcetera.com/3dsserver-saas/doc/current/releasenotes/2.5.1.0.html 

![](/media/grant/GORData/PlatformPAC-Projects/3ds-v2.0/doc/images/AdminUI_RRes_Notification_URL.PNG)



![](./images/3dsServerConfig.png)



#### The URL call from Postman:

```
http://localhost:9078/transaction/manager/3ds/v2/service/result/response
```

#### Body

```json
{
  "threeDSServerTransID": "8a880dc0-d2d2-4067-bcb1-b08d1690b26e",
  "transStatus": "Y",
  "authenticationValue": "MTIzNDU2Nzg5MDA5ODc2NTQzMjE=",
  "eci": "05",
  "resultsRequest": {
    "threeDSServerTransID":"8a880dc0-d2d2-4067-bcb1-b08d1690b26e",
    "acsTransID":"d7c1ee99-9478-44a6-b1f2-391e29c6b340",
    "acsRenderingType": {
      "acsInterface":"01",
      "acsUiTemplate":"01"
    },
    "authenticationMethod":"02",
    "authenticationType":"02",
    "authenticationValue":"MTIzNDU2Nzg5MDA5ODc2NTQzMjE=",
    "dsTransID":"f25084f0-5b16-4c0a-ae5d-b24808a95e4b",
    "eci":"05",
    "interactionCounter":"02",
    "messageCategory":"01",
    "messageType":"RReq",
    "messageVersion":"2.1.0",
    "transStatus":"Y"
  },
  "resultsResponse": {
    "threeDSServerTransID":"8a880dc0-d2d2-4067-bcb1-b08d1690b26e",
    "acsTransID":"d7c1ee99-9478-44a6-b1f2-391e29c6b340",
    "dsTransID":"f25084f0-5b16-4c0a-ae5d-b24808a95e4b",
    "messageType":"RRes",
    "messageVersion":"2.1.0",
    "resultsStatus":"01"
  },
  "errorDetails": null
}
```



# Test cards and Scenarios

## Visa:

| Card Number | Expected Response 3DS 2.x |
| ----------- | ------------------------- |
| 4556557955726624| AUTHENTICATED_APPLICATION_FRICTIONLESS|
|4916994064252017| BROWSER_CHALLENGE|
|4556104160382032| NOT_AUTHENTICATED_APPLICATION_FRICTIONLESS|
|4024007189449340|APPLICATION_CHALLENGE|
|4024007179872394 |APPLICATION_CHALLENGE_SDK_TRANS_ID_INVALID_FORM AT|
|4929251897047956|AUTHENTICATED_BROWSER_FRICTIONLESS|
|4716429323842524|NOT_AUTHENTICATED_BROWSER_FRICTIONLESS|
|4234123412340003||
|4604633194219929||
|4485436455354151|BROWSER_FRICTIONLESS_MISSING_DS_TRANS_ID|
|4556962659911995|APPLICATION_FRICTIONLESS_MISSING_SDK_TRANS_ID|
|4539837572943550|BROWSER_FRICTIONLESS_MISSING_DS_TRANS_ID|
|4024007176265022|BROWSER_CHALLENGE_MISSING_ACS_URL|
|4716125059847899|THREE_RI|
|4556362626719763|PROTOCOL_ERROR|
|4234123412340000||
|4234123412340006||
|4234123412340007||
|4234123412340001||
|4234123412340002|NOT ENROLLED (VeRes is error 404 "Card account number not found in card ranges from Directory Server")|
|4234123412340100||
|4234123412340101||
|4234123412340102||
|4234123412340103||
|4234123412340104||
|4234123412340105||
|4234123412340106||
|4234123412340107||
|4234123412340108||
|4234123412340109||
|4234123412340200||
|4234123412340201||
|4234123412340202||
|4234123412340203||
|4234123412340204||
|4234123412340205||
|4234123412340206||
|4234123412340220||
|4234123412340250||
|4234123412340251||
|4234123412340252||
|4234123412340253||
|4234123412340258||
|4234123412340298||
|4234123412340299||
|4234123412340300||
|4234123412340301||
|4234123412340350||
|4234123412340351||
|4234123412340352||
|4234123412340353||
|4234123412340354||
|4234123412340355||
|4234123412340356||
|4234123412340358||
|4234123412340399||
|4234123412340400||
|4234123412340401||
|4234123412340402||
|4234123412340403||



## Mastercard:

| Card Number | Expected Response 3DS 2.x |
| ------------| ------------------------- |
|5333259155643223|AUTHENTICATED_APPLICATION_FRICTIONLESS|
|5306889942833340| BROWSER_CHALLENGE|
|5328720384582224| NOT_AUTHENTICATED_APPLICATION_FRICTIONLESS|
|526764860892429| APPLICATION_CHALLENGE|
|5187434643593002|APPLICATION_CHALLENGE_SDK_TRANS_ID_INVALID_FORMAT|
|5512459816707531|AUTHENTICATED_BROWSER_FRICTIONLESS|
|5487971631330522| NOT_AUTHENTICATED_BROWSER_FRICTIONLESS| |5424184049821670|BROWSER_CHALLENGE| 
|5204240438720050123|BROWSER_CHALLENGE| 
|5250548692069390||
|5641523891636636||



## Amex:

| Card Number | Expected Response 3DS 2.x |
| ------------------------------------------------------------ | ---- |
| 341502098634895 | AUTHENTICATED_APPLICATION_FRICTIONLESS            |
| 348638267931507  | BROWSER_CHALLENGE                                 |
| 345695399207589 | NOT_AUTHENTICATED_APPLICATION_FRICTIONLESS |
| 349531373081938 | APPLICATION_CHALLENGE |
| 342316317472410 | APPLICATION_CHALLENGE_SDK_TRANS_ID_INVALID_FORMAT |
| 347899129656655 | AUTHENTICATED_BROWSER_FRICTIONLESS |
| 345197771649926 | NOT_AUTHENTICATED_BROWSER_FRICTIONLESS |
| 372021106351394 | BROWSER_CHALLENGE |
| 3734123412340000 |      |
| 3434567891111005 |      |
| 3794521996036850 |      |



## Ranges:

| Start range | End range | Schema |
| ----------- | --------- | ------ |
|340000000000000| 349999999999999| Amex|
|370000000000000|379999999999999|Amex|
|2221000000000000|2223000000000022|Mastercard|
|2223000000000024|2720999999999999|Mastercard|
|5100000000000000|5111111111111117|Mastercard|
|5111111111111119|5599999999999999|Mastercard|
|4000000000000000|4111110000000210|Visa|
|4111110000000212|34123412339999|Visa|
|4234123412350000|4999999999999999|Visa|

## OTP Codes:

### 3DS2:
| OTP Code | Transaction Status | Transaction Status reason | ECI  | authenticationValue |
| -------- | ------------------ | ------------------------- | ---- | ------------------- |
|1234|Y|/|01|JAmi21makAifmwqo2120cjq1AAA=|
|1111|N|01|01|/|
|2222|R|01|01|/|
|3333|U|01|01|/|
|4444|A|01|01|Qm181okmdyqh6yQmYuq1890QAAA=|

The same OTP codes are valid for Visa, Mastercard and Amex scenarios.



## Actual Tests



#### Authentication request:

http://localhost:9078/transaction/manager/3ds/v2/service/authentication

https://3dss.prev.netcetera-payment.ch/3ds-server/3ds/authentication/

```json
{
  "deviceChannel": "02",
  "messageCategory": "01",
  "threeDSCompInd": "Y",
  "threeDSRequestor": {
    "threeDSRequestorAuthenticationInd": "02",
    "threeDSRequestorAuthenticationInfo": {
      "threeDSReqAuthMethod": "04",
      "threeDSReqAuthTimestamp": "201812201735",
      "threeDSReqAuthData": "threeDSReqAuthData"
    },
    "threeDSRequestorChallengeInd": "03",
    "threeDSRequestorPriorAuthenticationInfo": {
      "threeDSReqPriorRef": "VOGXpZvTlCmBUyPnnZfmsGDKqxRsRwPovkAE",
      "threeDSReqPriorAuthMethod": "01",
      "threeDSReqPriorAuthTimestamp": "201812201735",
      "threeDSReqPriorAuthData": "threeDSReqPriorAuthData"
    }
  },
  "cardholderAccount": {
    "acctType": "02",
    "cardExpiryDate": "1812",
    "acctInfo": {
      "chAccAgeInd": "04",
      "chAccDate": "20181220",
      "chAccChangeInd": "03",
      "chAccChange": "20181220",
      "chAccPwChangeInd": "04",
      "chAccPwChange": "20181220",
      "shipAddressUsageInd": "03",
      "shipAddressUsage": "20181220",
      "txnActivityDay": 1,
      "txnActivityYear": 1,
      "provisionAttemptsDay": 1,
      "nbPurchaseAccount": 1,
      "suspiciousAccActivity": "01",
      "shipNameIndicator": "01",
      "paymentAccInd": "03",
      "paymentAccAge": "20181220"
    },
    "shipAddressUsageInd": "03",
    "shipAddressUsage": "20181220",
    "txnActivityDay": 1,
    "txnActivityYear": 1,
    "provisionAttemptsDay": 1,
    "nbPurchaseAccount": 1,
    "suspiciousAccActivity": "01",
    "shipNameIndicator": "01",
    "paymentAccInd": "03",
    "paymentAccAge": "20181220",
    "acctNumber": "4916994064252017",

    "schemeId": "Visa",
    "payTokenInd": true
  },
  "cardholder": {
    "addrMatch": "N",
    "billAddrCity": "Zurich",
    "billAddrCountry": "756",
    "billAddrLine1": "Zypressenstrasse 71",
    "billAddrLine2": "P.O. Box",
    "billAddrLine3": "8040 Zürich",
    "billAddrPostCode": "8000",
    "billAddrState": "CH",
    "email": "netcetera@example.com",
    "homePhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "mobilePhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "workPhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "cardholderName": "John Doe",
    "shipAddrCity": "Zurich",
    "shipAddrCountry": "756",
    "shipAddrLine1": "Zypressenstrasse 98",
    "shipAddrLine2": "P.O. Box",
    "shipAddrLine3": "8040 Zürich",
    "shipAddrPostCode": "8000",
    "shipAddrState": "CH"
  },
  "purchase": {
    "purchaseInstalData": 3,
    "merchantRiskIndicator": {
      "shipIndicator": "01",
      "deliveryTimeframe": "02",
      "deliveryEmailAddress": "netcetera@example.com",
      "reorderItemsInd": "01",
      "preOrderPurchaseInd": "01",
      "preOrderDate": "20181220",
      "giftCardAmount": 2,
      "giftCardCurr": "978",
      "giftCardCount": 1
    },
    "purchaseAmount": 1,
    "purchaseCurrency": "978",
    "purchaseExponent": 1,
    "purchaseDate": "20181220173550",
    "recurringExpiry": "20181220",
    "recurringFrequency": 1,
    "transType": "01"
  },
  "acquirer": {
    "acquirerBin": "acq-bin",
    "acquirerMerchantId": "acq-mer-id"
  },
  "merchant": {
    "mcc": "4511",
    "merchantCountryCode": "598",
    "merchantName": "IBE SALES AUD",
    "threeDSRequestorId": "ds-assigned-requestor-id",
    "threeDSRequestorName": "ds-assigned-requestor-name"
  },
  "broadInfo": {"message": "TLS 1.x will be turned off starting summer 2019 "},
  "messageExtension": [
    {
      "name": "name",
      "id": "id",
      "criticalityIndicator": false,
      "data": {
        "valueOne": "value1",
        "valueTwo":"value2"
      }
    }
  ],
  "browserInformation": {
    "browserAcceptHeader": "application/json",
    "browserIP": "192.168.1.11",
    "browserJavaEnabled": true,
    "browserLanguage": "en",
    "browserColorDepth": "8",
    "browserScreenHeight": 1,
    "browserScreenWidth": 1,
    "browserTZ": 1,
    "browserUserAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0",
    "challengeWindowSize": "01"
  }
}
```



```json
{
    "threeDSServerTransID": "a717be35-fb0b-4c69-846a-23b818a9f9a6",
    "acsURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge",
    "transStatus": "C",
    "authenticationValue": null,
    "eci": null,
    "acsChallengeMandated": "Y",
    "authenticationRequest": {
        "threeDSCompInd": "Y",
        "threeDSRequestorID": "ds-assigned-requestor-id",
        "threeDSRequestorName": "ds-assigned-requestor-name",
        "threeDSRequestorURL": "https://example.com/3ds-requestor-url",
        "acquirerBIN": "acq-bin",
        "acquirerMerchantID": "acq-mer-id",
        "addrMatch": "N",
        "cardExpiryDate": "1812",
        "acctNumber": "4916994064252017",
        "billAddrCity": "Zurich",
        "billAddrCountry": "756",
        "billAddrLine1": "Zypressenstrasse 71",
        "billAddrLine2": "P.O. Box",
        "billAddrLine3": "8040 Zürich",
        "billAddrPostCode": "8000",
        "billAddrState": "CH",
        "email": "netcetera@example.com",
        "homePhone": {
            "cc": "1",
            "subscriber": "123"
        },
        "mobilePhone": {
            "cc": "1",
            "subscriber": "123"
        }
    },
    "authenticationResponse": {
        "threeDSServerTransID": "a717be35-fb0b-4c69-846a-23b818a9f9a6",
        "acsTransID": "129991fb-155b-4756-9b82-a589d3a45137",
        "acsReferenceNumber": "3DS_LOA_ACS_201_13579",
        "acsOperatorID": "AcsOpId 4138359541",
        "dsReferenceNumber": "DS186937449533647030",
        "dsTransID": "eefbd5f3-5df7-4adb-b2ff-932dab8509e6",
        "sdkTransID": null,
        "transStatus": "C",
        "acsChallengeMandated": "Y",
        "messageType": "ARes",
        "messageVersion": "2.1.0"
    },
    "purchaseDate": "20181220173550",
    "errorDetails": null,
    "challengeRequest": {
        "threeDSServerTransID": "a717be35-fb0b-4c69-846a-23b818a9f9a6",
        "acsTransID": "129991fb-155b-4756-9b82-a589d3a45137",
        "messageType": "CReq",
        "messageVersion": "2.1.0",
        "challengeWindowSize": "01",
        "messageExtension": null
    },
    "base64EncodedChallengeRequest": "eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImE3MTdiZTM1LWZiMGItNGM2OS04NDZhLTIzYjgxOGE5ZjlhNiIsImFjc1RyYW5zSUQiOiIxMjk5OTFmYi0xNTViLTQ3NTYtOWI4Mi1hNTg5ZDNhNDUxMzciLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"
}
```

### versioning request

http://localhost:9078/transaction/manager/3ds/v2/service/versioning

https://3dss.prev.netcetera-payment.ch/3ds-server/3ds/v2/versioning/

```json
{
  "cardholderAccountNumber": "4556557955726624",
  "schemeId": "Visa"
}
```



```json
{
    "threeDSServerTransID": "6234691d-99b1-414c-89d4-abb163243f05",
    "acsStartProtocolVersion": "2.1.0",
    "acsEndProtocolVersion": "2.2.0",
    "dsStartProtocolVersion": "2.1.0",
    "dsEndProtocolVersion": "2.2.0",
    "highestCommonSupportedProtocolVersion": "2.2.0",
    "acsInfoInd": null,
    "threeDSMethodURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method",
    "threeDSMethodDataForm": {
        "threeDSMethodData": "eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9leGFtcGxlLmNvbS8zZHMtbWV0aG9kLW5vdGlmaWNhdGlvbi11cmwiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjYyMzQ2OTFkLTk5YjEtNDE0Yy04OWQ0LWFiYjE2MzI0M2YwNSJ9"
    },
    "threeDSMethodData": {
        "threeDSMethodNotificationURL": "https://example.com/3ds-method-notification-url",
        "threeDSServerTransID": "6234691d-99b1-414c-89d4-abb163243f05"
    },
    "errorDetails": null
}
```

