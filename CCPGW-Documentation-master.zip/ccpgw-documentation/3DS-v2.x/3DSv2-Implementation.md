 ![](../headerImages/PlatformPAC.png)



# Netcetera 3DS 2.x Implementation 

###### version: 1.0.0





<img align="left" width="100" height="120" src="../headerImages/GrantOReilly.png"/>

Author: <span style="color:blue">**Grant Blaise O'Reilly PhD.**</span>

###### **Java Developer and System Architect**

email: grant@platformpac.com.pg

## Introduction 

### Overview

This document covers the how to for Netcetera for 3DS version 1 in the  internet payment gateway. 

#### Netcetera publicly available technical guides:

3DS MPI https://3dsserver.netcetera.com/doc/current
3DS Server (on-prem)  https://3dsserver.netcetera.com/3dsserver/doc/current/
3DS Server (SaaS)  https://3dsserver.netcetera.com/3dsserver-saas/doc/current/
3DS SDK:  https://3dssdk.netcetera.com/3dssdk/doc/current/
3DS SDK Marketing Video  https://www.youtube.com/watch?v=kpsfvWsw7bA



## Documentation and Links

| Product Name            | Technical mdescription                                     |
| ----------------------- | ---------------------------------------------------------- |
| 3DS Acquiring Microsite | https://3dss.netcetera.com/                                |
| 3DS Server SaaS         | https://3dss.netcetera.com/3dsserver-saas/doc/current/     |
| NDM simulator           | https://3dss.netcetera.com/3dsserver/ndmsimulator/current/ |
| 3DS SDK                 | https://3dss.netcetera.com/3dssdk/doc/current/             |



#### 3DS Server SaaS - Useful Links

| Admin propereties                         | Links |
| ----------------------------------------------- | -------- |
| 3DS Server Admin on payment platform Preview environment |	https://3dss-admin.prev.netcetera-payment.ch/admin/ |
| 3DS Server Admin on payment platform Production environment |	https://3dss-admin.netcetera-payment.ch/admin/ |


| Server         | Links      |
| ---------------| -----------|
| 3DS Server - PP Preview |  https://3dss.prev.netcetera-payment.ch/3ds-server/ |
| 3DS Server - PP Production | https://3dss.netcetera-payment.ch/3ds-server/ |

| Other | Links |
|----------|---------|
| 3DS Server SaaS Integration Manual (includes the main endpoints for 3DS 1.0 and 2.X) | https://3dss.netcetera.com/3dsserver-saas/doc/current/integration.html |
| 3DS 2.x API + Flow |	https://3dss.netcetera.com/3dsserver-saas/doc/current/schema/3ds-api.html |
|3DS 1.0 API |	https://3dss.netcetera.com/3dsserver-saas/doc/current/schema/3ds-1-api/api-3ds.html |
| |	https://3dss.netcetera.com/3dsserver-saas/doc/2.5.2.0/3ds-2.x-api |
|3DS 1.0 Flow |	https://3dss.netcetera.com/3dsserver-saas/doc/current/schema/3ds-1-api/api-3ds.html#a3DS_1.0_Flow |
|Admin - Validate and Reload configuration|https://3dss.netcetera.com/3dsserver-saas/doc/current/admin/admin-validate.html|
|Admin - Timeouts and URLs configuration|https://3dss.netcetera.com/3dsserver-saas/doc/current/admin/admin-timeouts.html|
|Admin - Merchant / Acquirer configuration|https://3dss.netcetera.com/3dsserver-saas/doc/current/admin/admin-merchant-acquirer.html|
|3DS Server SaaS - Release Notes|https://3dss.netcetera.com/3dsserver-saas/doc/current/releasenotes/2.2.5.0.html|
|Examples of Authentication requests|https://3dss.netcetera.com/3dsserver-saas/doc/current/schema/3ds-authentication.html#Authentication_Request_Model|
|Examples of Authentication responses|https://3dss.netcetera.com/3dsserver-saas/doc/current/schema/3ds-authentication.html#Authentication_Response_Model|





## Admin UI

You will receive the e-mail for activation of the user for the 3DS Server Admin UI from Netcetera. Upon access to the Admin UI you can configure it's Acquires/Merchants as it's described in the documentation:

​       


goreilly N3tc3t3r@196908

API access 

The password to access the APIs would be provided via SMS to your mobile phone.



3DS 2.x API base URL: https://3dss-preview-server.extranet.netcetera.biz/3ds

3DS 1.x API base URL: https://3dss-preview-server.extranet.netcetera.biz/mpi/v1





3dss-preview-tech-user W7Ldsmy6fTW3qrP


These are the base URLs. Please find information of the specific endpoints handling 3DS requests under:



Any HTTP request sent to the APIs should be accompanied with the next two HTTP headers:  



3DS-Organization-ID
cd9cf664-4fd1-4acb-bb49-1453c087b7fa
Authorization
Basic credentials 
User : 3dss-preview-tech-user
Password: W7Ldsmy6fTW3qrP



## Service Portal

```
https://serviceportal.netcetera.com/sp
```
```
username: grantoreilly 

password: N3tc3t3r@1969
```

![](images/ServicePortal.png)


![](images/ServicePortal-2.png)

## ExtraNet

```
https://admin.extranet.netcetera.biz/admin
```

```
username: grantoreilly 

password: N3tc3t3r@1969
```


![](images/Extranet.png)

![](/media/grant/GORData/PlatformPAC-Projects/3ds-v2.0/doc/images/Extranet-2.png)

![](/images/Plaza.png)



https://3dsserver.netcetera.com/3dsserver/ndmsimulator/current/config/simulator-3ds1.html
https://3dsserver.netcetera.com/3dsserver/ndmsimulator/current/config/simulator-3ds2.html





## Trouble shooting

For 3DS 2 authentication, the API should be: https://3dss.prev.netcetera-payment.ch/3ds-server/3ds/authentication 

Only versioning has 2 'versions' which can be accessed with: 

https://3dss.prev.netcetera-payment.ch/3ds-server/3ds/versioning 

https://3dss.prev.netcetera-payment.ch/3ds-server/3ds/v2/versioning 

But the authentication is only one so far, all these apis are for 3DS 2 protocol. 



You can find more information on the APIs here: 

https://3dsserver.netcetera.com/3dsserver-saas/doc/2.5.2.0/integration-manual#3ds-server-web-service-api  
