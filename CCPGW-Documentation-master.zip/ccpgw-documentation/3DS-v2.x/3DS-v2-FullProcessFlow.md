  ![](../headerImages//PlatformPAC.png)



# Netcetera 3DS 2.x Full Process Flow

###### version: 1.0.0

<img align="left" width="100" height="120" src="../headerImages//GrantOReilly.png"/>

Author: <span style="color:blue">**Grant Blaise O'Reilly PhD.**</span>

###### **Java Developer and System Architect**

email: grant@platformpac.com.pg



# Two-step 3DS 2.x flow from Sabre

###### Method 1b: Dynamic 3DS (Alternative Flow)

We call this flow as the 2-step flow. (Two AuthRQ requests are sent to the CCPGW)

Below are steps in this flow:

1. Sabre sends first AuthRQ to CCPGW

2. CCPGW sends 3DS-Versioning-Request to your Netcetera. 

3. Netcetera replys to CCPGW with a 3DS-Versioning-Response.

4. CCPGW identifies version from  3DS-Versioning-Response and sends an IssuerURL to Sabre (In this case a CCPGW component  https://ccpgw.testbsp.com.pg/3dsredirectmechanism ). 

5. Sabre redirects user to CCPGW URL (i.e. https://ccpgw.testbsp.com.pg/3dsredirectmechanism). Sabre will include its return URLs in this redirection.

   ​	See the Notification manager: 

   ```bash
   ========================================================
   Received Issuer call from Sabre ..........
   ========================================================
   KeyValuePair :MD 4001PGK00000005
   KeyValuePair :TermUrl https://ipe-pmt.cert.sabre.com/ipe/3DS?merchantReference=01411654737971006177&merchantId=PX
   
   Success <!DOCTYPE html><html lang="en"><head>    <meta charset="UTF-8"/>    <title>Identifying...</title></head><body><script>    var tdsMethodNotificationValue = 'eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImViMmI2YzY5LWNjOGMtNGYwZC05NTM4LTA1OTFjODMzYzJkYSJ9';    var form = document.createElement("form");    form.setAttribute("method", "post");    form.setAttribute("action", "https://ccpgw.testbsp.com.pg/3dsmethodnotification");    addParameter(form, "threeDSMethodData", tdsMethodNotificationValue);    document.body.appendChild(form);    form.submit();    function addParameter(form, key, value) {        var hiddenField = document.createElement("input");        hiddenField.setAttribute("type", "hidden");        hiddenField.setAttribute("name", key);        hiddenField.setAttribute("value", value);        form.appendChild(hiddenField);    }</script></body></html>
   ```

6. CCPGW redirects user to ACS/3DS-Method-URL received from the earlier 3DS-Versioning-Request. This triggers device data collection and then ACS sends results to CCPGW.

   see the Notification manager: 

   ```bash
   ========================================================
   Received 3DS v2.x Method Data response from Netcetera Server
   ========================================================
   KeyValuePair :threeDSMethodData eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImViMmI2YzY5LWNjOGMtNGYwZC05NTM4LTA1OTFjODMzYzJkYSJ9
   ```

7. BSP then sends the Authentication-Request.

8. If response from ACS indicates a challenge is needed, BSP redirects user to the ACS-challenge-URL.

9. After challenge is completed, ACS returns results to BSP. (BSP will need to facilitate possible multiple challenges)

10. BSP then redirects user back to Sabre page and includes the challenge response (Cres / PaRes)

11. Sabre sends the second AuthRQ request to BSP including challenge response (Cres / PaRes)

12. BSP processes authorization and sends outcome to Sabre
    11.Sabre redirects user to POS page.

Sequence diagram for this flow is listed below. (POS is Point-Of-Sale application, SEPG is Sabre Enterprise Payment Gateway, Vendor is BSP)



# Reverse Proxy Mappings

|             SIT  External Proxy Servers             |||
| ------------ | ------------ |------------- |
| PMPLPACPROXY0301|172.16.41.85 | Reverse Proxy |
| PMPLPACPROXY0302|172.16.41.90 | Reverse Proxy |



## External reverse proxy

1./ Add the ProxyPass and ProxyPassReverse into the ssl.conf

```bash
vi /etc/httpd/conf.d/ssl.conf
```

```bash
   ...
   ProxyPass "/3dsresultresponse" "https://ccpgw.testbsp.com.pg/3dsresultresponse" 
   ProxyPassReverse "/3dsresultresponse" "https://ccpgw.testbsp.com.pg/3dsresultresponse" 

   ProxyPass "/3dsnotification" "https://ccpgw.testbsp.com.pg/3dsnotification" 
   ProxyPassReverse "/3dsnotification" "https://ccpgw.testbsp.com.pg/3dsnotification" 

   ProxyPass "/3dsmethodnotification" "https://ccpgw.testbsp.com.pg/3dsmethodnotification" 
   ProxyPassReverse "/3dsmethodnotification" "https://ccpgw.testbsp.com.pg/3dsmethodnotification" 

   ProxyPass "/3dsredirectmechanism" "https://ccpgw.testbsp.com.pg/3dsredirectmechanism" 
   ProxyPassReverse "/3dsredirectmechanism" "https://ccpgw.testbsp.com.pg/3dsredirectmechanism"
   ...
```

2./ Add the |3dsresultresponse|3dsnotification|3dsmethodnotification|3dsredirectmechanism|into the truteq.conf

```bash
vi /etc/httpd/conf.d/truteq.conf

```

```bash
<If "%{REQUEST_URI} !~ m#^/(sabre|postilion|transaction|keycloak|admin|merchant|registermerchant|creditcardpayment|transaction|ccpgw-admin|notification|3dsresultresponse|3dsnotification|3dsmethodnotification|3dsredirectmechanism|check.html)#i">
    RedirectMatch permanent "^/.*$" "https://bsp.com.pg/"
</If>

```



# Sabre 

## Setting up transaction

```http
https://ipe.int.sabre.com/pwsair/
https://pwsair.int.sabre.com/shop#no-back-button
```

| Parameter          | Value     |
| ------------------ | --------- |
| Username           | bspuser   |
| Password           | Bsp@Pws21 |
| PNR/Confirmation # | 12312344  |
| Station ID         | 99999992  |

### VISA Test Cards:

| Credit Card #    | Expected Response                      | Transaction Status | Passed |
| ---------------- | -------------------------------------- | ------------------ | ------ |
| 4916994064252017 | BROWSER_CHALLENGE                      | C                  | YES    |
| 4556557955726624 | AUTHENTICATED_APPLICATION_FRICTIONLESS | Y                  | NO     |
| 5306889942833340 | BROWSER_CHALLENGE                      |                    |        |

5293890109903731 - Non enrolled

4999999999999004 - Visa non-enrolled

5100000000000016 - Mastercard non-enrolled

Visa
4999999999999160 -- AUTHENTICATED_BROWSER_FRICTIONLESS (Versioning without threeDSMethodURL) - TransStatus Y
4999999999999186 -- ATTEMPTED_BROWSER_FRICTIONLESS (Versioning without threeDSMethodURL) - TransStatus A

Mastercard
5100000000001006 -- AUTHENTICATED_BROWSER_FRICTIONLESS (Versioning without threeDSMethodURL) - TransStatus Y
5100000000001022 -- ATTEMPTED_BROWSER_FRICTIONLESS (Versioning without threeDSMethodURL) - TransStatus A

![](images/SabreLogin.png)



![](images/SabreMerchantSettings.png)


![](images/SabreCardDetails.png)

##  use card #: 4916994064252017



# Monitoring on CCPGW Sabre SOAP Frontend Adapter and Notification manager

ssh ccpgw@10.160.30.95

docker logs -f ipgwsabreadapter



ssh ccpgw@10.160.30.93

docker logs -f ipgwsabreadapter



### CCPGW Sabre SOAP Frontend Adapter

```bash
2022-06-09 11:26:16 DEBUG FilterChainProxy:208 -Securing POST /sabre/auth
2022-06-09 11:26:16 DEBUG SecurityContextPersistenceFilter:102 -Set SecurityContextHolder to empty SecurityContext
2022-06-09 11:26:16 DEBUG DaoAuthenticationProvider:199 -Authenticated user
2022-06-09 11:26:16 DEBUG BasicAuthenticationFilter:158 -Set SecurityContextHolder to UsernamePasswordAuthenticationToken [Principal=org.springframework.security.core.userdetails.User [Username=Sabre_IPGW_adapter, Password=[PROTECTED], Enabled=true, AccountNonExpired=true, credentialsNonExpired=true, AccountNonLocked=true, Granted Authorities=[ROLE_USER]], Credentials=[PROTECTED], Authenticated=true, Details=WebAuthenticationDetails [RemoteIpAddress=172.77.0.3, SessionId=null], Granted Authorities=[ROLE_USER]]
2022-06-09 11:26:16 DEBUG HttpSessionSecurityContextRepository:399 -Created HttpSession as SecurityContext is non-default
2022-06-09 11:26:16 DEBUG HttpSessionSecurityContextRepository:361 -Stored SecurityContextImpl [Authentication=UsernamePasswordAuthenticationToken [Principal=org.springframework.security.core.userdetails.User [Username=Sabre_IPGW_adapter, Password=[PROTECTED], Enabled=true, AccountNonExpired=true, credentialsNonExpired=true, AccountNonLocked=true, Granted Authorities=[ROLE_USER]], Credentials=[PROTECTED], Authenticated=true, Details=WebAuthenticationDetails [RemoteIpAddress=172.77.0.3, SessionId=null], Granted Authorities=[ROLE_USER]]] to HttpSession [org.apache.catalina.session.StandardSessionFacade@1c85969b]
2022-06-09 11:26:16 DEBUG FilterSecurityInterceptor:210 -Authorized filter invocation [POST /sabre/auth] with attributes [hasRole('ROLE_USER')]
2022-06-09 11:26:16 DEBUG FilterChainProxy:323 -Secured POST /sabre/auth
2022-06-09 11:26:16 DEBUG WebServiceMessageReceiverHandlerAdapter:127 -Accepting incoming [org.springframework.ws.transport.http.HttpServletConnection@7c8cd370] at [http://ipgwsabreadapter:9091/sabre/auth]
2022-06-09 11:26:16 DEBUG received:172 -Received request [SaajSoapMessage {https://ipgw.testbsp.com.pg/sabre}AuthRQ]
2022-06-09 11:26:16 DEBUG PayloadRootAnnotationMethodEndpointMapping:66 -Looking up endpoint for [{https://ipgw.testbsp.com.pg/sabre}AuthRQ]
2022-06-09 11:26:16 DEBUG SoapMessageDispatcher:265 -Endpoint mapping [org.springframework.ws.server.endpoint.mapping.PayloadRootAnnotationMethodEndpointMapping@78e2d1af] maps request to endpoint [public com.truteq.ccpgw.payment.gateway.api.soap.AuthRS com.truteq.ccpgw.frontend.adapter.sabre.api.endpoints.AuthRQEndpoint.getAuth(com.truteq.ccpgw.payment.gateway.api.soap.AuthRQ)]
2022-06-09 11:26:16 DEBUG SoapMessageDispatcher:285 -Testing endpoint adapter [org.springframework.ws.server.endpoint.adapter.DefaultMethodEndpointAdapter@7ed803ad]
2022-06-09 11:26:16 DEBUG XmlRootElementPayloadMethodProcessor:138 -Unmarshalled payload request to [com.truteq.ccpgw.payment.gateway.api.soap.AuthRQ@5ebc5f7c]
2022-06-09 11:26:16 INFO  AuthRQEndpoint:84 -getAuth:285: No T3DS: Step1.
2022-06-09 11:26:16 INFO  AuthRQEndpoint:84 -getAuth:294: Order number: 01411654737971006177
2022-06-09 11:26:16 INFO  AuthRQEndpoint:84 -getAuth:295: Transaction Id: 1654737976771
2022-06-09 11:26:16 INFO  PaymentGatewayHandler:84 -setMerchantCurrencyMap:2238: Read MerchantCurrencyMap from database using merchantAccountCode, currency and stationNumber = 1009319144 and PGK and 99999992
2022-06-09 11:26:16 DEBUG PaymentGatewayHandler:65 -keystore: /config/keystore/platformpacKS.p12
2022-06-09 11:26:16 DEBUG PaymentGatewayHandler:65 -keystorepassword: platformpac
2022-06-09 11:26:16 DEBUG SSLCommunicator:71 -sendHttpPost:123: Response:{"autoGeneratedMid":"4001PGK00000005","autoGeneratedTid":"401PGK05","code":"598","cardAcceptorNameLocation":"AIR NIUGINI PGK        POM            PG","stationNumber":"99999992"}
2022-06-09 11:26:16 INFO  PaymentGatewayHandler:84 -process3DSStepOneVersion2x:1053: Card scheme: VI
2022-06-09 11:26:16 INFO  PaymentGatewayHandler:84 -process3DSStepOneVersion2x:1061: Setting schemeId for Visa.
2022-06-09 11:26:16 INFO  PaymentGatewayHandler:84 -process3DSv2xVersioningRequest:946: Card scheme: Visa
2022-06-09 11:26:18 DEBUG SSLCommunicator:71 -sendHttpPost:123: Response:{"threeDSServerTransID":"ade1e13f-627f-4689-b6cc-03f122b0a7c6","acsStartProtocolVersion":"2.1.0","acsEndProtocolVersion":"2.2.0","dsStartProtocolVersion":"2.1.0","dsEndProtocolVersion":"2.2.0","highestCommonSupportedProtocolVersion":"2.2.0","acsInfoInd":null,"threeDSMethodURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method","threeDSMethodDataForm":{"threeDSMethodData":"eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9jY3Bndy50ZXN0YnNwLmNvbS5wZy8zZHNtZXRob2Rub3RpZmljYXRpb24iLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImFkZTFlMTNmLTYyN2YtNDY4OS1iNmNjLTAzZjEyMmIwYTdjNiJ9"},"threeDSMethodData":{"threeDSMethodNotificationURL":"https://ccpgw.testbsp.com.pg/3dsmethodnotification","threeDSServerTransID":"ade1e13f-627f-4689-b6cc-03f122b0a7c6"},"errorDetails":null}
2022-06-09 11:26:18 DEBUG PaymentGatewayHandler:71 -process3DSv2xVersioningRequest:953: Success {"threeDSServerTransID":"ade1e13f-627f-4689-b6cc-03f122b0a7c6","acsStartProtocolVersion":"2.1.0","acsEndProtocolVersion":"2.2.0","dsStartProtocolVersion":"2.1.0","dsEndProtocolVersion":"2.2.0","highestCommonSupportedProtocolVersion":"2.2.0","acsInfoInd":null,"threeDSMethodURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method","threeDSMethodDataForm":{"threeDSMethodData":"eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9jY3Bndy50ZXN0YnNwLmNvbS5wZy8zZHNtZXRob2Rub3RpZmljYXRpb24iLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImFkZTFlMTNmLTYyN2YtNDY4OS1iNmNjLTAzZjEyMmIwYTdjNiJ9"},"threeDSMethodData":{"threeDSMethodNotificationURL":"https://ccpgw.testbsp.com.pg/3dsmethodnotification","threeDSServerTransID":"ade1e13f-627f-4689-b6cc-03f122b0a7c6"},"errorDetails":null}
2022-06-09 11:26:18 INFO  PaymentGatewayHandler:84 -process3DSv2xVersioningRequest:959: Versioning Response :{"threeDSServerTransID":"ade1e13f-627f-4689-b6cc-03f122b0a7c6","acsStartProtocolVersion":"2.1.0","acsEndProtocolVersion":"2.2.0","dsStartProtocolVersion":"2.1.0","dsEndProtocolVersion":"2.2.0","highestCommonSupportedProtocolVersion":"2.2.0","threeDSMethodURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method","threeDSMethodDataForm":{"threeDSMethodData":"eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9jY3Bndy50ZXN0YnNwLmNvbS5wZy8zZHNtZXRob2Rub3RpZmljYXRpb24iLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImFkZTFlMTNmLTYyN2YtNDY4OS1iNmNjLTAzZjEyMmIwYTdjNiJ9"},"threeDSMethodData":{"threeDSMethodNotificationURL":"https://ccpgw.testbsp.com.pg/3dsmethodnotification","threeDSServerTransID":"ade1e13f-627f-4689-b6cc-03f122b0a7c6"}}
2022-06-09 11:26:18 DEBUG PaymentGatewayHandler:65 -CurrencyCode: 598
2022-06-09 11:26:18 DEBUG PaymentGatewayHandler:65 -AuthReq: {"preferredProtocolVersion":"2.1.0","enforcePreferredProtocolVersion":false,"deviceChannel":"02","messageCategory":"01","threeDSCompInd":"Y","threeDSRequestor":{"threeDSRequestorAuthenticationInd":"02","threeDSRequestorAuthenticationInfo":{"threeDSReqAuthMethod":"04","threeDSReqAuthTimestamp":"202206091126","threeDSReqAuthData":"threeDSReqAuthData"},"threeDSRequestorChallengeInd":"03","threeDSRequestorPriorAuthenticationInfo":{"threeDSReqPriorRef":"VOGXpZvTlCmBUyPnnZfmsGDKqxRsRwPovkAE","threeDSReqPriorAuthMethod":"01","threeDSReqPriorAuthTimestamp":"202206091126","threeDSReqPriorAuthData":"threeDSReqPriorAuthData"},"threeDSRequestorDecReqInd":"N","threeDSRequestorDecMaxTime":10080},"threeDSServerTransID":"","threeDSRequestorURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method","cardholderAccount":{"acctType":"02","cardExpiryDate":"2206","acctInfo":{"chAccAgeInd":"04","chAccDate":"20181220","chAccChangeInd":"03","chAccChange":"20181220","chAccPwChangeInd":"04","chAccPwChange":"20181220","shipAddressUsageInd":"03","shipAddressUsage":"20181220","txnActivityDay":"1","txnActivityYear":"1","provisionAttemptsDay":"1","nbPurchaseAccount":"1","suspiciousAccActivity":"01","shipNameIndicator":"01","paymentAccInd":"03","paymentAccAge":"20181220"},"acctNumber":"4916994064252017","schemeId":"Visa","acctID":"","payTokenInd":true},"cardholder":{"addrMatch":"N","billAddrCity":"","billAddrCountry":"","billAddrLine1":"","billAddrLine2":"","billAddrLine3":"","billAddrPostCode":"","billAddrState":"","email":"","homePhone":{"cc":"1","subscriber":"123"},"mobilePhone":{"cc":"1","subscriber":"123"},"workPhone":{"cc":"1","subscriber":"123"},"cardholderName":"Grant O\u0027Reilly","shipAddrCity":"","shipAddrCountry":"","shipAddrLine1":"","shipAddrLine2":"","shipAddrLine3":"","shipAddrPostCode":"","shipAddrState":""},"purchase":{"purchaseInstalData":3,"purchaseAmount":100,"purchaseCurrency":"598","purchaseExponent":2,"purchaseDate":"20220609112618","recurringExpiry":"20220609","recurringFrequency":1,"transType":"01"},"acquirer":{"acquirerBin":"428280","acquirerMerchantId":"Visa"},"merchant":{"merchantConfigurationId":"","mcc":"4511","merchantCountryCode":"598","merchantName":"IBE SALES PGK","threeDSRequestorId":"ds-assigned-requestor-id","threeDSRequestorName":"ds-assigned-requestor-name","whiteListStatus":"Y"},"broadInfo":{"message":"TLS 1.x will be turned off starting summer 2019"},"messageExtension":[{"name":"name","id":"id","criticalityIndicator":false,"data":{"valueOne":"value1","ValueTwo":"value2"}}],"browserInformation":{"browserAcceptHeader":"application/json","browserIP":"192.168.1.11","browserJavaEnabled":true,"browserLanguage":"en","browserColorDepth":"8","browserScreenHeight":1,"browserScreenWidth":1,"browserTZ":1,"browserUserAgent":"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0","challengeWindowSize":"01","browserJavascriptEnabled":true}}
2022-06-09 11:26:20 DEBUG SSLCommunicator:71 -sendHttpPost:123: Response:{"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge","transStatus":"C","authenticationValue":null,"eci":null,"acsChallengeMandated":"Y","authenticationRequest":{"threeDSCompInd":"Y","threeDSRequestorID":"ds-assigned-requestor-id","threeDSRequestorName":"ds-assigned-requestor-name","threeDSRequestorURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method","acquirerBIN":"428280","acquirerMerchantID":"Visa","addrMatch":"N","cardExpiryDate":"2206","acctNumber":"4916994064252017","billAddrCity":null,"billAddrCountry":null,"billAddrLine1":null,"billAddrLine2":null,"billAddrLine3":null,"billAddrPostCode":null,"billAddrState":null,"email":null,"homePhone":{"cc":"1","subscriber":"123"},"mobilePhone":{"cc":"1","subscriber":"123"}},"authenticationResponse":{"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsTransID":"2a197f10-0a93-42c8-bef4-8a9f598336a3","acsReferenceNumber":"3DS_LOA_ACS_201_13579","acsOperatorID":"AcsOpId 4138359541","dsReferenceNumber":"DS186937449533647030","dsTransID":"0a1fdbcf-a17e-4778-923b-d434559e0cd0","sdkTransID":null,"transStatus":"C","acsChallengeMandated":"Y","messageType":"ARes","messageVersion":"2.1.0"},"purchaseDate":"20220609112618","errorDetails":null,"challengeRequest":{"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsTransID":"2a197f10-0a93-42c8-bef4-8a9f598336a3","messageType":"CReq","messageVersion":"2.1.0","challengeWindowSize":"01","messageExtension":null},"base64EncodedChallengeRequest":"eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImU0ZmZjMTIwLTg5OTgtNDVmMi1iYzIwLTFhYWRkMjJkMjMxNyIsImFjc1RyYW5zSUQiOiIyYTE5N2YxMC0wYTkzLTQyYzgtYmVmNC04YTlmNTk4MzM2YTMiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"}
2022-06-09 11:26:20 DEBUG PaymentGatewayHandler:71 -process3DSv2xAuthenticationRequest:1029: Success {"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge","transStatus":"C","authenticationValue":null,"eci":null,"acsChallengeMandated":"Y","authenticationRequest":{"threeDSCompInd":"Y","threeDSRequestorID":"ds-assigned-requestor-id","threeDSRequestorName":"ds-assigned-requestor-name","threeDSRequestorURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method","acquirerBIN":"428280","acquirerMerchantID":"Visa","addrMatch":"N","cardExpiryDate":"2206","acctNumber":"4916994064252017","billAddrCity":null,"billAddrCountry":null,"billAddrLine1":null,"billAddrLine2":null,"billAddrLine3":null,"billAddrPostCode":null,"billAddrState":null,"email":null,"homePhone":{"cc":"1","subscriber":"123"},"mobilePhone":{"cc":"1","subscriber":"123"}},"authenticationResponse":{"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsTransID":"2a197f10-0a93-42c8-bef4-8a9f598336a3","acsReferenceNumber":"3DS_LOA_ACS_201_13579","acsOperatorID":"AcsOpId 4138359541","dsReferenceNumber":"DS186937449533647030","dsTransID":"0a1fdbcf-a17e-4778-923b-d434559e0cd0","sdkTransID":null,"transStatus":"C","acsChallengeMandated":"Y","messageType":"ARes","messageVersion":"2.1.0"},"purchaseDate":"20220609112618","errorDetails":null,"challengeRequest":{"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsTransID":"2a197f10-0a93-42c8-bef4-8a9f598336a3","messageType":"CReq","messageVersion":"2.1.0","challengeWindowSize":"01","messageExtension":null},"base64EncodedChallengeRequest":"eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImU0ZmZjMTIwLTg5OTgtNDVmMi1iYzIwLTFhYWRkMjJkMjMxNyIsImFjc1RyYW5zSUQiOiIyYTE5N2YxMC0wYTkzLTQyYzgtYmVmNC04YTlmNTk4MzM2YTMiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"}
2022-06-09 11:26:20 INFO  PaymentGatewayHandler:84 -process3DSv2xAuthenticationRequest:1035: Authentication Response :{"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge","transStatus":"C","acsChallengeMandated":"Y","authenticationRequest":{"threeDSCompInd":"Y","threeDSRequestorID":"ds-assigned-requestor-id","threeDSRequestorName":"ds-assigned-requestor-name","threeDSRequestorURL":"https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method","acquirerBIN":"428280","acquirerMerchantID":"Visa","addrMatch":"N","cardExpiryDate":"2206","acctNumber":"4916994064252017","homePhone":{"cc":"1","subscriber":"123"},"mobilePhone":{"cc":"1","subscriber":"123"}},"authenticationResponse":{"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsTransID":"2a197f10-0a93-42c8-bef4-8a9f598336a3","acsReferenceNumber":"3DS_LOA_ACS_201_13579","acsOperatorID":"AcsOpId 4138359541","dsReferenceNumber":"DS186937449533647030","dsTransID":"0a1fdbcf-a17e-4778-923b-d434559e0cd0","transStatus":"C","acsChallengeMandated":"Y","messageType":"ARes","messageVersion":"2.1.0"},"purchaseDate":"20220609112618","challengeRequest":{"threeDSServerTransID":"e4ffc120-8998-45f2-bc20-1aadd22d2317","acsTransID":"2a197f10-0a93-42c8-bef4-8a9f598336a3","messageType":"CReq","messageVersion":"2.1.0","challengeWindowSize":"01"},"base64EncodedChallengeRequest":"eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImU0ZmZjMTIwLTg5OTgtNDVmMi1iYzIwLTFhYWRkMjJkMjMxNyIsImFjc1RyYW5zSUQiOiIyYTE5N2YxMC0wYTkzLTQyYzgtYmVmNC04YTlmNTk4MzM2YTMiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"}
2022-06-09 11:26:20 INFO  PaymentGatewayHandler:78 -Setting IssuerURL to: https://ccpgw.testbsp.com.pg/3dsredirectmechanism
2022-06-09 11:26:20 INFO  PaymentGatewayHandler:78 -Setting merchant data: {"autoGeneratedMid":"4001PGK00000005","autoGeneratedTid":"401PGK05","code":"598","cardAcceptorNameLocation":"AIR NIUGINI PGK        POM            PG","stationNumber":"99999992"}
2022-06-09 11:26:20 INFO  PaymentGatewayHandler:84 -PersistACS:599: Saving the ACS and PaReq to database
2022-06-09 11:26:20 INFO  PaymentGatewayHandler:84 -PersistACS:600: Calling: https://ccpgw.testbsp.com.pg:9078/transaction/manager/database/write/acspareq and writing {"acsurl":"https://ccpgw.testbsp.com.pg/3dsredirectmechanism","pareq":"eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImU0ZmZjMTIwLTg5OTgtNDVmMi1iYzIwLTFhYWRkMjJkMjMxNyIsImFjc1RyYW5zSUQiOiIyYTE5N2YxMC0wYTkzLTQyYzgtYmVmNC04YTlmNTk4MzM2YTMiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"}
2022-06-09 11:26:20 DEBUG SSLCommunicator:71 -sendHttpPost:123: Response:
2022-06-09 11:26:20 DEBUG XmlRootElementPayloadMethodProcessor:101 -Marshalling [com.truteq.ccpgw.payment.gateway.api.soap.AuthRS@3f93665a] to response payload
2022-06-09 11:26:20 DEBUG sent:182 -Sent response [SaajSoapMessage {https://ipgw.testbsp.com.pg/sabre}AuthRS] for request [SaajSoapMessage {https://ipgw.testbsp.com.pg/sabre}AuthRQ]
2022-06-09 11:26:20 DEBUG HttpSessionSecurityContextRepository:361 -Stored SecurityContextImpl [Authentication=UsernamePasswordAuthenticationToken [Principal=org.springframework.security.core.userdetails.User [Username=Sabre_IPGW_adapter, Password=[PROTECTED], Enabled=true, AccountNonExpired=true, credentialsNonExpired=true, AccountNonLocked=true, Granted Authorities=[ROLE_USER]], Credentials=[PROTECTED], Authenticated=true, Details=WebAuthenticationDetails [RemoteIpAddress=172.77.0.3, SessionId=null], Granted Authorities=[ROLE_USER]]] to HttpSession [org.apache.catalina.session.StandardSessionFacade@1c85969b]
2022-06-09 11:26:20 DEBUG MessageDispatcherServlet:1131 -Completed 200 OK
2022-06-09 11:26:20 DEBUG HttpSessionSecurityContextRepository:361 -Stored SecurityContextImpl [Authentication=UsernamePasswordAuthenticationToken [Principal=org.springframework.security.core.userdetails.User [Username=Sabre_IPGW_adapter, Password=[PROTECTED], Enabled=true, AccountNonExpired=true, credentialsNonExpired=true, AccountNonLocked=true, Granted Authorities=[ROLE_USER]], Credentials=[PROTECTED], Authenticated=true, Details=WebAuthenticationDetails [RemoteIpAddress=172.77.0.3, SessionId=null], Granted Authorities=[ROLE_USER]]] to HttpSession [org.apache.catalina.session.StandardSessionFacade@1c85969b]
2022-06-09 11:26:20 DEBUG SecurityContextPersistenceFilter:118 -Cleared SecurityContextHolder to complete request

```



### Notification manager

```bash
========================================================
Received Issuer call from Sabre ..........
========================================================
KeyValuePair :MD 4001PGK00000005
KeyValuePair :TermUrl https://ipe-pmt.cert.sabre.com/ipe/3DS?merchantReference=01411654737971006177&merchantId=PX

Success <!DOCTYPE html><html lang="en"><head>    <meta charset="UTF-8"/>    <title>Identifying...</title></head><body><script>    var tdsMethodNotificationValue = 'eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImViMmI2YzY5LWNjOGMtNGYwZC05NTM4LTA1OTFjODMzYzJkYSJ9';    var form = document.createElement("form");    form.setAttribute("method", "post");    form.setAttribute("action", "https://ccpgw.testbsp.com.pg/3dsmethodnotification");    addParameter(form, "threeDSMethodData", tdsMethodNotificationValue);    document.body.appendChild(form);    form.submit();    function addParameter(form, key, value) {        var hiddenField = document.createElement("input");        hiddenField.setAttribute("type", "hidden");        hiddenField.setAttribute("name", key);        hiddenField.setAttribute("value", value);        form.appendChild(hiddenField);    }</script></body></html>

========================================================
Received 3DS v2.x Method Data response from Netcetera Server
========================================================
KeyValuePair :threeDSMethodData eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImViMmI2YzY5LWNjOGMtNGYwZC05NTM4LTA1OTFjODMzYzJkYSJ9

```

The process is:

1. Run http://localhost:9078/transaction/manager/3ds/v2/service/versioning
2. This results in 

```json
{
    "threeDSServerTransID": "4c9e12f1-ea26-423d-915f-d9d72b8af57e",
    "acsStartProtocolVersion": "2.1.0",
    "acsEndProtocolVersion": "2.2.0",
    "dsStartProtocolVersion": "2.1.0",
    "dsEndProtocolVersion": "2.2.0",
    "highestCommonSupportedProtocolVersion": "2.2.0",
    "acsInfoInd": null,
    "threeDSMethodURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method",
    "threeDSMethodDataForm": {
        "threeDSMethodData": "eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9jY3Bndy50ZXN0YnNwLmNvbS5wZy8zZHNtZXRob2Rub3RpZmljYXRpb24iLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjRjOWUxMmYxLWVhMjYtNDIzZC05MTVmLWQ5ZDcyYjhhZjU3ZSJ9"
    },
    "threeDSMethodData": {
        "threeDSMethodNotificationURL": "https://ccpgw.testbsp.com.pg/3dsmethodnotification",
        "threeDSServerTransID": "4c9e12f1-ea26-423d-915f-d9d72b8af57e"
    },
    "errorDetails": null
}
```

3./ Run https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method with

```json
threeDSMethodData = "eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9jY3Bndy50ZXN0YnNwLmNvbS5wZy8zZHNtZXRob2Rub3RpZmljYXRpb24iLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjRjOWUxMmYxLWVhMjYtNDIzZC05MTVmLWQ5ZDcyYjhhZjU3ZSJ9"
```

This results in:

```html
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<title>Identifying...</title>
</head>

<body>
	<script>
		var tdsMethodNotificationValue = 'eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjRjOWUxMmYxLWVhMjYtNDIzZC05MTVmLWQ5ZDcyYjhhZjU3ZSJ9';

    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", "https://ccpgw.testbsp.com.pg/3dsmethodnotification");

    addParameter(form, "threeDSMethodData", tdsMethodNotificationValue);

    document.body.appendChild(form);
    form.submit();

    function addParameter(form, key, value) {
        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", key);
        hiddenField.setAttribute("value", value);
        form.appendChild(hiddenField);
    }
	</script>
</body>
```

4. Now if one decodes 'eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjRjOWUxMmYxLWVhMjYtNDIzZC05MTVmLWQ5ZDcyYjhhZjU3ZSJ9'' using Base64.getDecoder().decode

   ```json
   {"threeDSServerTransID":"4c9e12f1-ea26-423d-915f-d9d72b8af57e"}
   //                       4c9e12f1-ea26-423d-915f-d9d72b8af57e same as in step 2.
   ```

   

