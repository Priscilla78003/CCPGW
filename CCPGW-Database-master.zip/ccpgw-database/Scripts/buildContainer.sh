#!/bin/sh
#sudo chown -vR grant:grant ./data
#sudo rm -vrf data/
sudo docker build -t mariadb-ccpgwtransactdb .
