$JAVA_HOME/bin/xjc -d src -p com.truteq.ccpgw.netcetera.model  -XautoNameResolution Netcetera.xsd
