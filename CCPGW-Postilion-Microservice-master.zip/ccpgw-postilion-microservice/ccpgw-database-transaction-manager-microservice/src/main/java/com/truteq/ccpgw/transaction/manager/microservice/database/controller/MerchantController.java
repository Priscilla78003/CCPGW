/*
 * ***************************************************************
 * Truteq Credit Card Payment Gateway (CCPGW) version 1.0.0
 * ***************************************************************
 * Copyright (c) 2021 Truteq Australia 2019
 * ***************************************************************
 * CCPGW Transaction Manager Microservice : Transaction Manager - Restful Web service 
 * Support: Grant O'Reilly gbo@truteq.com
 * V01.00.00  14-Apr-2021 
 * ***************************************************************
 */
package com.truteq.ccpgw.transaction.manager.microservice.database.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.truteq.ccpgw.communication.server.logging.wrapper.LogWrapper;
import com.truteq.ccpgw.transaction.manager.merchant.portal.authenticate.authorise.EncryptionOnly;
import com.truteq.ccpgw.transaction.manager.merchant.portal.model.ReactJSMerchantObj;
import com.truteq.ccpgw.transaction.manager.merchant.portal.model.Result;
import com.truteq.ccpgw.transaction.manager.model.Merchant;
import com.truteq.crypto.CryptoUtil;
import com.truteq.datagenerics.GenericDatabaseDAO;
import java.util.Base64;
import org.apache.tomcat.util.buf.HexUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 *
 * @author mho
 */
@RestController
@PropertySource("classpath:datamanager.properties")
@RequestMapping("/transaction/manager/database/")
public class MerchantController {

    private final LogWrapper mLogger = new LogWrapper(MerchantController.class);
    
    @Autowired
    private GenericDatabaseDAO databaseDao;
    
    @Value(value = "${keycloak.admin.server.url}")
    private String serverUrl;
    @Value(value = "${keycloak.admin.realm}")
    private String realm;
    @Value(value = "${keycloak.admin.client-id}")
    private String clientId;
    @Value(value = "${keycloak.admin.client-secret}")
    private String clientSecret;     
    

    @PostMapping("merchant/read")
    @CrossOrigin(origins = "*")
    public String getMerchant(@RequestBody Merchant merchantin) throws Exception {

        Merchant merchant = (Merchant) databaseDao.findByName("ccpgw.transaction.manager.read.merchant", Merchant.class, merchantin.getSecretkey());
        
        mLogger.debug("merchant/read MerchantController toJSON(merchant) = " + toJSON(merchant));
        return toJSON(merchant);
    }

    @PostMapping("merchant/rsaprivatekey/read")
    @CrossOrigin(origins = "*")
    public String getMerchantPrivateKey(@RequestBody Merchant merchantin) throws Exception {
        Merchant merchant = (Merchant) databaseDao.findByName("ccpgw.transaction.manager.read.merchant.privatekey", Merchant.class, merchantin.getGuid());

        return toJSON(merchant);
    }

    private String toJSON(Object obj) {
        Gson gson = new GsonBuilder().create();
        return gson.toJson(obj);
    }
    
//    /**
//     * =========================================================================
//     * @param key
//     * @param guid
//     * @param encryptedValue
//     * @return 
//     * =========================================================================
//     */
//    private String decryptPayload(String key, String guid, String encryptedValue) {
//
//        CryptoUtil cryptoUtil = new CryptoUtil();
//        
//        String RsaPrivateKey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBALktsEvZmUBcMs2fxvifrBin1m5EAiuTvTGNYXTlTciUD1hZeHkpilVKHx/GmRnZOFgtzbLnffikSn/Yo/eeiZxQ+0LvTokqwYNI8j2ryp1eYjze7afQDhDdig8EfjnjAOz9NU75EY8fWZ//hOBpOoIHFVLZJaE07OzeVOl2BlNHAgMBAAECgYBK5aLXmuQ0NtZJeqVUa+iEdGXzZUhnbbLo9uEDEbe7N79ZIZ7ripSr2HXsOTw1SzlR2PzIrn6x8Wk8elgfUB0hzx/EBo9aPVNHpsk8xV/qB1L5meq+aBspYtANeYuAhwbAu33WWmeKeA7mIEIq+Ol8oRemzQ4QRpUQYIffs9uSuQJBAOAjkge7wbAjt8cOka3jzCQiIkzJKPkcEYGxCjjhNq9wWqhdHfRn6bvWQXptruIAcrqHzjfaIla+CJu2U/am4CUCQQDTgFgd9mvC/yzPMRB0zVr5jXa1I6H+3YIsneGOztE1GP2gpK2aEf2MmolcSI/iaVvLB2uSIigp0eqINhp1naP7AkBBTxwF1NejE0VBYyVfnbil7qw/431k2KDhQUzRNg5RIFPKKxfHV1/rs4pwufTzNV44q8mSzKSk0cqAVKgyfn1hAkBNBuUQpHpCniR3oOrZXyDO2hJtjfillY6fKTDIjdHrgJp+Mvt2rS6mUnHMRjEAyFZB7wXiRsZR1L2RtgKU60CZAkAm4C3GKIQ7qTczOq+jnFtgzBHqEb9KcJ2LJ8eOztmmvbNE2PfTffoufw4pKkktfER7I/N/YzsLmmAHN6FXBFea";
//
//        String encAesKeyBase64 = key;
//        //decode from Base64 format
//        byte[] encAesKeyBytes = Base64.getDecoder().decode(encAesKeyBase64);
//        //decrypt AES key with private RSA key
//        byte[] decryptedAesKeyHex = null;
//        try {
//            decryptedAesKeyHex = cryptoUtil.decryptWithPrivateRsaKey(encAesKeyBytes, RsaPrivateKey);
//        } catch (Exception ex) {
//            mLogger.error("Error decrypting AES key with private RSA key, Exception = " + ex);
//        }
//
//        byte[] decryptedAesKey = HexUtils.fromHexString(new String(decryptedAesKeyHex));
//
//        //initialization vector - 1st 16 chars of userId
//        byte[] iv = guid.substring(0, 16).getBytes();
//
//        byte[] encTransBytes = Base64.getDecoder().decode(encryptedValue);
//
//        //decrypt transaction payload with AES key
//        byte[] decrypted = null;
//        try {
//            decrypted = cryptoUtil.decryptWithAes(encTransBytes, decryptedAesKey, iv);
//            mLogger.info("Decrypted transaction: " + new String(decrypted));
//        } catch (Exception ex) {
//            mLogger.error("Error decrypting AES transaction payload with AES key, Exception = " + ex);
//        }
//        
//        return new String(decrypted);
//        
//    }
//    /**
//     * =========================================================================
//     * decryptPayloadToMerchant
//     * @param key
//     * @param guid
//     * @param encryptedValue
//     * @return 
//     * =========================================================================
//     */
//    private ReactJSMerchantObj decryptPayloadToMerchant(String key, String guid, String encryptedValue){
//        
//        String transactionData = decryptPayload(key,guid,encryptedValue);
//        Gson gson = new Gson();
//        ReactJSMerchantObj transactionObj = gson.fromJson(transactionData, ReactJSMerchantObj.class);
//        return transactionObj;        
//    }
//
//    
//    /**=========================================================================
//     * @param merchant
//     * @return
//     * =========================================================================
//    */
//    @PostMapping(path = "merchant/create", consumes = "application/json")
//    @CrossOrigin(origins = "*")
//    public ResponseEntity CreateMerchant(@RequestBody com.truteq.ccpgw.transaction.manager.merchant.portal.model.Merchant merchant) {
//        
//        ObjectManagerUtil objManager = new ObjectManagerUtil(databaseDao);
//        
//        objManager.setServerUrl(this.serverUrl);
//        objManager.setRealm(this.realm);
//        objManager.setClientId(this.clientId);
//        objManager.setClientSecret(this.clientSecret);
//        
//        
//        HttpHeaders headers = new HttpHeaders();
//        
//        com.truteq.ccpgw.transaction.manager.merchant.portal.model.Merchant db_merchant = objManager.createMerchant(merchant);
//        
//        return ResponseEntity.ok().headers(headers).body(new Result(200, "Successful!", "Created merchant: "+ db_merchant.getBusinessName()));
//    } 
//    
//    /**=========================================================================
//     * ReactJSCreateMerchant
//     * @param encryptionObj
//     * @return 
//     * =========================================================================
//     */
//    @PostMapping(path = "merchant/createfrom/reactjs", consumes = "application/json")
//    @CrossOrigin(origins = "*")
//    public ResponseEntity ReactJSCreateMerchant(@RequestBody EncryptionOnly encryptionObj) {
//        
//        ReactJSMerchantObj reactjsMerchant = decryptPayloadToMerchant(encryptionObj.getKey(),encryptionObj.getGuid(), encryptionObj.getEncryption());
//        
//        return CreateMerchant(new com.truteq.ccpgw.transaction.manager.merchant.portal.model.Merchant(reactjsMerchant));
//    }
    
    
}
