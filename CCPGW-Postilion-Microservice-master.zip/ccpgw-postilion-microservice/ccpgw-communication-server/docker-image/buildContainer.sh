sudo docker build -t microservice-ccpgw-communication-server-1.34.0 .
