/*
 * ***************************************************************
 * Truteq Internet Payment Gateway (IPGW) version 1.0.0
 * ***************************************************************
 * Copyright (c) 2020 Truteq Australia 2019
 * ***************************************************************
 * IPGW API - Microservice for Truteq IPGW project 
 * Support: Grant O'Reilly gbo@truteq.com
 * V01.00.00  20-Dec-2019 
 * ***************************************************************
 */
package com.truteq.ccpgw.transaction.manager.merchant.portal.model;

import com.google.gson.Gson;
import java.util.Date;

/**
 *
 * @author Grant Blaise O'Reilly <gbo@truteq.com>
 */
public class Order {

    private Integer orderId;
    private Double amount;
    private String merchant;
    private String customer_first_name;
    private String customer_last_name;
    private String customer_email;
    private String currency;
    private String description;    
    private Date datetime;    
    private String transaction_ref;
    private String status_value;
    private String status;
    private String status_description; 
        
    public String toJSON(){
        Gson gson =new Gson();
        return gson.toJson(this);
    }     
    /**
     * @return the orderId
     */
    public Integer getOrderId() {
        return orderId;
    }

    /**
     * @param orderId the orderId to set
     */
    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    /**
     * @return the amount
     */
    public Double getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    /**
     * @return the merchant
     */
    public String getMerchant() {
        return merchant;
    }

    /**
     * @param merchant the merchant to set
     */
    public void setMerchant(String merchant) {
        this.merchant = merchant;
    }

    /**
     * @return the customer_first_name
     */
    public String getCustomer_first_name() {
        return customer_first_name;
    }

    /**
     * @param customer_first_name the customer_first_name to set
     */
    public void setCustomer_first_name(String customer_first_name) {
        this.customer_first_name = customer_first_name;
    }

    /**
     * @return the customer_last_name
     */
    public String getCustomer_last_name() {
        return customer_last_name;
    }

    /**
     * @param customer_last_name the customer_last_name to set
     */
    public void setCustomer_last_name(String customer_last_name) {
        this.customer_last_name = customer_last_name;
    }

    /**
     * @return the customer_email
     */
    public String getCustomer_email() {
        return customer_email;
    }

    /**
     * @param customer_email the customer_email to set
     */
    public void setCustomer_email(String customer_email) {
        this.customer_email = customer_email;
    }

    /**
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @param currency the currency to set
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
    
    /**
     * @return the datetime
     */
    public Date getDatetime() {
        return datetime;
    }

    /**
     * @param datetime the datetime to set
     */
    public void setDatetime(Date datetime) {
        this.datetime = datetime;
    }

    /**
     * @return the transaction_ref
     */
    public String getTransaction_ref() {
        return transaction_ref;
    }

    /**
     * @param transaction_ref the transaction_ref to set
     */
    public void setTransaction_ref(String transaction_ref) {
        this.transaction_ref = transaction_ref;
    }

    /**
     * @return the status_value
     */
    public String getStatus_value() {
        return status_value;
    }

    /**
     * @param status_value the status_value to set
     */
    public void setStatus_value(String status_value) {
        this.status_value = status_value;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the status_description
     */
    public String getStatus_description() {
        return status_description;
    }

    /**
     * @param status_description the status_description to set
     */
    public void setStatus_description(String status_description) {
        this.status_description = status_description;
    }
}
