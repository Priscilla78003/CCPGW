  ![](../headerImages//PlatformPAC.png)



# Redirection Mechanism for 3DS 2.x Process Flow

###### version: 1.1.0

<img align="left" width="100" height="120" src="../headerImages//GrantOReilly.png"/>

Author: <span style="color:blue">**Grant Blaise O'Reilly PhD.**</span>

###### **Java Developer and System Architect**

email: grant@platformpac.com.pg



[TOC]

<div style="page-break-after: always"></div>

# Introduction

This document describes the redirection mechanism in the 3DS2.x process flow. Each step in the redirection mechanism in the 3DS2.x process flow is discussed in detail.



## Servers

| SIT  Servers   |              |            |
| -------------- | ------------ | ---------- |
| PMPLPACAPP0301 | 10.160.30.95 | App server |
| PMPLPACWEB0301 | 10.160.30.93 | Web server |



## Reverse Proxy Mappings

| SIT  External Proxy Servers |              |               |
| --------------------------- | ------------ | ------------- |
| PMPLPACPROXY0301            | 172.16.41.85 | Reverse Proxy |
| PMPLPACPROXY0302            | 172.16.41.90 | Reverse Proxy |



<div style="page-break-after: always"></div>

# Notification URLs

Key URLs used in the redirection mechanism in the 3DS2.x process flow:

![](/media/grant/GORData/Truteq-Gitea-Server-Repo/PlatformPAC/CCPGW-Documentation/3DS-v2.x/images/netceteraURLs-1.7.png)

| URL notification type        | Actual URL                                         |
| ---------------------------- | -------------------------------------------------- |
| Notifivation URL             | https://ccpgw.testbsp.com.pg/3dsnotification       |
| Result Response URL          | https://ccpgw.testbsp.com.pg/3dsresultresponse     |
| Three DS Requestor           | https://ccpgw.testbsp.com.pg/3dsrequestor          |
| Sabre call                   | https://ccpgw.testbsp.com.pg/3dsredirectmechanism  |
| Three DS Method Notification | https://ccpgw.testbsp.com.pg/3dsmethodnotification |

<div style="page-break-after: always"></div>

## External reverse proxy

1./ Add the ProxyPass and ProxyPassReverse into the ssl.conf

```bash
vi /etc/httpd/conf.d/ssl.conf
```

```bash
   ...
   ProxyPass "/3dsresultresponse" "https://ccpgw.testbsp.com.pg/3dsresultresponse" 
   ProxyPassReverse "/3dsresultresponse" "https://ccpgw.testbsp.com.pg/3dsresultresponse" 

   ProxyPass "/3dsnotification" "https://ccpgw.testbsp.com.pg/3dsnotification" 
   ProxyPassReverse "/3dsnotification" "https://ccpgw.testbsp.com.pg/3dsnotification" 

   ProxyPass "/3dsmethodnotification" "https://ccpgw.testbsp.com.pg/3dsmethodnotification" 
   ProxyPassReverse "/3dsmethodnotification" "https://ccpgw.testbsp.com.pg/3dsmethodnotification" 

   ProxyPass "/3dsredirectmechanism" "https://ccpgw.testbsp.com.pg/3dsredirectmechanism" 
   ProxyPassReverse "/3dsredirectmechanism" "https://ccpgw.testbsp.com.pg/3dsredirectmechanism"
   ...
```

2./ Add the |3dsresultresponse|3dsnotification|3dsmethodnotification|3dsredirectmechanism|into the truteq.conf

```bash
vi /etc/httpd/conf.d/truteq.conf
```

```bash
<If "%{REQUEST_URI} !~ m#^/(sabre|postilion|transaction|keycloak|admin|merchant|registermerchant|creditcardpayment|transaction|ccpgw-admin|notification|3dsresultresponse|3dsnotification|3dsmethodnotification|3dsredirectmechanism|check.html)#i">
    RedirectMatch permanent "^/.*$" "https://bsp.com.pg/"
</If>

```

<div style="page-break-after: always"></div>

# 3DS2x Redirection Mechanism

![](drawio/RedirectMechanism3DSv2.svg)

| Step | Operation                                                    |
| ---- | ------------------------------------------------------------ |
| 1    | This takes place from the Sabre server (Browser [Sabre] in the diagram). We call this flow as the 2-step flow. <br>(Two AuthRQ requests are sent to the CCPGW). Here Sabre sends first AuthRQ to CCPGW. |
| 2    | The CCPGW received the SOAP request (AuthReq) from Sabre. <br>The CCPGW then sends a 3DS-Versioning request to the Netcertera 3DS Server. <br>The process is: Run http://localhost:9078/transaction/manager/3ds/v2/service/versioning <br>**Note:** The call is to the Transaction Manager i.e. http://localhost:9078/transaction/manager/3ds/v2/service/versioning <br>points to the ThreeDSV2controller described below.    **Body**:{   "cardholderAccountNumber": "4556557955726624",   "schemeId": "Visa" } |
| 3    | Netcetera replys to CCPGW with a 3DS-Versioning-Response.    |
| 4    | The CCPGW will persist the versioning object (including if the card in enrolled or not enrolled). As well as the URL to the ACS. |
| 5    | Response back to Sabre frfom the CCPGW. CCPGW identifies version from 3DS-Versioning-Response  <br/>and sends an IssuerURL to Sabre (In this case a CCPGW component  https://ccpgw.testbsp.com.pg/3dsredirectmechanism ). |
| 6    | Sabre redirects user to CCPGW URL (i.e. https://ccpgw.testbsp.com.pg/3dsredirectmechanism).  <br/>Sabre will include its return URLs in this redirection. |
| 7    | Run https://3dss.extranet.netcetera.biz/3dss-demo/acs/3ds-method with threeDSMethodData = "eyJ0aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly9jY3Bndy50ZXN0Yn...<br>NwLmNvbS5wZy8zZHNtZXRob2Rub3RpZmljYXRpb24iLCJ0aHJlZURTU2VydmVyVHJhbnNJR...<br>CI6IjRjOWUxMmYxLWVhMjYtNDIzZC05MTVmLWQ5ZDcyYjhhZjU3ZSJ9<br>This results in:    <br/><!DOCTYPE html> <html lang="en">   <br/><head> 	<meta charset="UTF-8" /> 	<title>Identifying...</title> </head>  <br/> <body> 	<script> 		 <br/>var tdsMethodNotificationValue = 'eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjRjOWUxMmYxLWVhMjYtNDIzZC05MTVmLWQ5ZDcyYjhhZjU3ZSJ9';      var form = document.createElement("form");     form.setAttribute("method", "post");      <br/>form.setAttribute("action", "https://ccpgw.testbsp.com.pg/3dsmethodnotification");       <br/>addParameter(form, "threeDSMethodData", tdsMethodNotificationValue);      <br/> document.body.appendChild(form);     form.submit();       <br/>function addParameter(form, key, value) { <br/>         var hiddenField = document.createElement("input"); <br/>         hiddenField.setAttribute("type", "hidden"); <br/>         hiddenField.setAttribute("name", key);  <br/>        hiddenField.setAttribute("value", value);    <br/>      form.appendChild(hiddenField);     } 	 <br/></script> </body> |
| 8    | CCPGW redirection mechanism redirects user to ACS/3DS-Method-URL received from the earlier 3DS-Versioning-Request. <br>This triggers device data collection and then ACS sends results to CCPGW.<br>KeyValuePair :threeDSMethodData eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImViMmI2YzY5LWNjOGMtNGYwZC05NTM4LTA1OTFjODMzYzJkYSJ9<br>Now if one decodes 'eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjRjOWUxMmYxLWVhMjYtNDIzZC05MTVmLWQ5ZDcyYjhhZjU3ZSJ9'' <br>using Base64.getDecoder().decode |
| 9    | CCPGW redirection mechanism then sends the Authentication-Request. <br>http://localhost:9078/transaction/manager/3ds/v2/service/authentication |
| 10   | Authentication response from 3DS Server (Netcetera).         |
| 11   | Persist the authenication data to the database.              |
| 12   | Receive the notification message from the 3DS server. Process the notification in the redirection mechanism. |
| 13   | If response from ACS indicates a challenge is needed, BSP redirects user to the ACS-challenge-URL. |
| 14   | After challenge is completed, ACS returns results to BSP. (BSP will need to facilitate possible multiple challenges) |
| 15   | BSP then redirects user back to Sabre page and includes the challenge response (Cres / PaRes) |
| 16   | Sabre receives the challenge request (CReq).                 |
| 17   | Sabre sends the second AuthRQ request to BSP including challenge response (Cres / PaRes) |
| 18   | The redirection mechanism receives the result response from the Netcetera 3DS server. |
| 19   | The redirection mechanism then persists the result response. |
| 20   | The CCPGW will query the database for the required persisted data for the preparation of the request messages to Position. |
| 21   | Send the 0100 authorisation message to Postilion.            |
| 22   | Received the 0110 authoristation response message from Postilion |
| 23   | Respond back to Sabre for the Auth Req message (i.e. the STEP 2) received in step 17. |
| 24   | Browser notifies CCPGW on the outcome.                       |

<div style="page-break-after: always"></div>

# Sabre 

## Setting up transaction

```http
https://ipe.int.sabre.com/pwsair/
```

| Parameter          | Value    |
| ------------------ | -------- |
| Username           | bspuser  |
| Password           |          |
| PNR/Confirmation # | 12312344 |
| Station ID         | 99999992 |

### VISA Test Cards:

| Credit Card #    | Expected Response                      | Transaction Status | Passed |
| ---------------- | -------------------------------------- | ------------------ | ------ |
| 4916994064252017 | BROWSER_CHALLENGE                      | C                  | YES    |
| 4556557955726624 | AUTHENTICATED_APPLICATION_FRICTIONLESS | Y                  | NO     |



![](/media/grant/GORData/Truteq-Gitea-Server-Repo/PlatformPAC/CCPGW-Documentation/3DS-v2.x/images/SabreLogin.png)



![](/media/grant/GORData/Truteq-Gitea-Server-Repo/PlatformPAC/CCPGW-Documentation/3DS-v2.x/images/SabreMerchantSettings.png)


![](/media/grant/GORData/Truteq-Gitea-Server-Repo/PlatformPAC/CCPGW-Documentation/3DS-v2.x/images/SabreCardDetails.png)



