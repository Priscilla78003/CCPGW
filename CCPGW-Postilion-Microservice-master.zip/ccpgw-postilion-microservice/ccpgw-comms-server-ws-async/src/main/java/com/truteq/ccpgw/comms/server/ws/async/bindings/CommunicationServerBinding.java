/*
 * ***************************************************************
 * Truteq Credit Card Payment Gateway (CCPGW) version 1.0.0
 * ***************************************************************
 * Copyright (c) 2021 Truteq Australia 2019
 * ***************************************************************
 * CCPGW Postilion Restful server : POSTILION - Restful Web service 
 * Support: Grant O'Reilly gbo@truteq.com
 * V01.00.00  14-Apr-2021 
 * ***************************************************************
 */
package com.truteq.ccpgw.comms.server.ws.async.bindings;

import com.truteq.ccpgw.comms.server.model.Terminate;
import com.truteq.ccpgw.comms.server.model.Disconnect;
import com.truteq.ccpgw.comms.server.model.CommsServerMessage;
import com.truteq.ccpgw.comms.server.model.Initiate;
import java.io.IOException;

/**
 *
 * @author Grant Blaise O'Reilly <gbo@truteq.com>
 */
public class CommunicationServerBinding extends Node {
    
    private final int port;
    private final String hostname;
    private String name = "";
    
    public CommunicationServerBinding(String hostname, int port){
        super(hostname, port);
        try {
            write(new Initiate("Postilion Web service","Web service used to send postilion commands via HTTP."));
        } catch (IOException ex) {
            mlogger.error("Exception: Initiate message error.", ex);
        }
        this.hostname = hostname;
        this.port = port;
    }
    
    public CommunicationServerBinding(String hostname, int port, String name){
        super(hostname, port);
        this.name = name;
        try {
            write(new Initiate(name,"Web service used to send postilion commands via HTTP."));
        } catch (IOException ex) {
            mlogger.error("Exception: Initiate message error.", ex);
        }
        this.hostname = hostname;
        this.port = port;
    }    
    
    public CommsServerMessage sendMessage(CommsServerMessage message) throws IOException, ClassNotFoundException{
        write(message);
        Object obj = waitForResponse();
        CommsServerMessage mrec = (CommsServerMessage)obj;
        return mrec;        
    }
    
    public void disconnect() throws IOException{
         write(new Disconnect(this.name));
    }
    
//    public Request sendMessage(Message message, String from) throws IOException, ClassNotFoundException{
//        write(message);
//        Object obj = waitForResponse();
//        Message mrec = (Message)obj;
//        return mrec.getRequest();        
//    }
    
     public void asktoShutDownServer() throws IOException, ClassNotFoundException{
         write(new Terminate());
    }    

    /**
     * @return the port
     */
    public int getPort() {
        return port;
    }
    
}