  ![](../headerImages/PlatformPAC.png)



# Netcetera 3DS 2.x Development: Controller  

###### version: 1.0.0

<img align="left" width="100" height="120" src="../headerImages//GrantOReilly.png"/>

Author: <span style="color:blue">**Grant Blaise O'Reilly PhD.**</span>

###### **Java Developer and System Architect**

email: grant@platformpac.com.pg



# Certificates

![](images/3dsPrevCert.png)

<img src="images/ipgw-test-bsp-Cert.png" />

```shell
openssl pkcs12 -export -name "3dssprevca" -in a93e6455-3ffc-498d-9d64-84fa22dc7095.pem -inkey a93e6455-3ffc-498d-9d64-84fa22dc7095.key -out mycerts.p12
Enter Export Password: mycerts
Verifying - Enter Export Password: mycerts
```

```shell
keytool -importcert -file ipgw.testbsp.com.pg2.crt -alias ipgwtestbsp -keystore mycerts.p12

keytool -importcert -file DigiCertCA2.crt -alias digicert -keystore mycerts.p12

keytool -list -keystore mycerts.p12 -v
```



# ThreeDSV2controller



## Versioning 



### Call from Postman

```
http://localhost:9078/transaction/manager/3ds/v2/service/versioning
```

**Note:** The call is to the Transaction Manager i.e. http://localhost:9078/transaction/manager/3ds/v2/service/versioning points to the ThreeDSV2controller described below.

#### Body

```json
{
  "cardholderAccountNumber": "8944988785642183",
  "schemeId": "Visa"
}
```
#### Response
```json
{
    "threeDSServerTransID": "450d1dde-e841-445e-b19f-0f286109e8ba",
    "acsStartProtocolVersion": null,
    "acsEndProtocolVersion": null,
    "dsStartProtocolVersion": null,
    "dsEndProtocolVersion": null,
    "highestCommonSupportedProtocolVersion": null,
    "acsInfoInd": null,
    "threeDSMethodURL": null,
    "threeDSMethodDataForm": null,
    "threeDSMethodData": null,
    "errorDetails": null
}
```

### Controller

```java
/**
 *
 * @author Grant Blaise O'Reilly <gbo@truteq.com>
 */

@RestController
@RequestMapping("/transaction/manager/3ds/v2/service/")
public class ThreeDSV2controller {

    @Value(value = "${certificate.keystore}")
    private String keystore;
    @Value(value = "${netcetera.keystore.password}")
    private String encryptedkeystorepassword;
    @Value(value = "${spring.encryption.secret}")        
    private String secret;
    
    private final LogWrapper mLogger = new LogWrapper(ThreeDSController.class);

    @PostMapping("versioning")
    @CrossOrigin(origins = "*")
    public ThreeDSServerVersioningResponse Versioning (@RequestBody ThreeDSV2ServerVersioningRequest versionReq) {
        mLogger.info("received 3DS v2.x Versioning Request: " + versionReq.toJSON());

       String keystorepassword = "";
        try {
            AESEncryptionDecryption decryptor = new AESEncryptionDecryption();
            keystorepassword = decryptor.decrypt(encryptedkeystorepassword, secret);         
        } catch (Exception ex) {
            mLogger.error("Exception with decryption credentials." + ex, new Throwable().getStackTrace()[0]);
        }
        
        SSLCommunicator sslComms = new SSLCommunicator(keystore,keystorepassword);
        Result result = sslComms.sendHttpPost("https://3dss.prev.netcetera-payment.ch/3ds-server/3ds/v2/versioning/", versionReq.toJSON().getBytes());
        
        mLogger.info(result.getComments() + " " + result.getData());

        Gson gson = new Gson();

        ThreeDSServerVersioningResponse versionResponse = gson.fromJson(result.getData(), ThreeDSServerVersioningResponse.class);

        return versionResponse;

    }    
}
```



## Authentication



### Call from Postman

```
http://localhost:9078/transaction/manager/3ds/v2/service/authentication
```

**Note:** The call is to the Transaction Manager i.e. http://localhost:9078/transaction/manager/3ds/v2/service/authentication points to the ThreeDSV2controller described below.

```  
Add the following to the header:
Key = 3DS-Organization-ID  Value= a93e6455-3ffc-498d-9d64-84fa22dc7095 
```

#### Body

```json
{
  "deviceChannel": "02",
  "messageCategory": "01",
  "threeDSCompInd": "Y",
  "threeDSRequestor": {
    "threeDSRequestorAuthenticationInd": "02",
    "threeDSRequestorAuthenticationInfo": {
      "threeDSReqAuthMethod": "04",
      "threeDSReqAuthTimestamp": "201812201735",
      "threeDSReqAuthData": "threeDSReqAuthData"
    },
    "threeDSRequestorChallengeInd": "03",
    "threeDSRequestorPriorAuthenticationInfo": {
      "threeDSReqPriorRef": "VOGXpZvTlCmBUyPnnZfmsGDKqxRsRwPovkAE",
      "threeDSReqPriorAuthMethod": "01",
      "threeDSReqPriorAuthTimestamp": "201812201735",
      "threeDSReqPriorAuthData": "threeDSReqPriorAuthData"
    }
  },
  "cardholderAccount": {
    "acctType": "02",
    "cardExpiryDate": "1812",
    "acctInfo": {
      "chAccAgeInd": "04",
      "chAccDate": "20181220",
      "chAccChangeInd": "03",
      "chAccChange": "20181220",
      "chAccPwChangeInd": "04",
      "chAccPwChange": "20181220",
      "shipAddressUsageInd": "03",
      "shipAddressUsage": "20181220",
      "txnActivityDay": 1,
      "txnActivityYear": 1,
      "provisionAttemptsDay": 1,
      "nbPurchaseAccount": 1,
      "suspiciousAccActivity": "01",
      "shipNameIndicator": "01",
      "paymentAccInd": "03",
      "paymentAccAge": "20181220"
    },
    "shipAddressUsageInd": "03",
    "shipAddressUsage": "20181220",
    "txnActivityDay": 1,
    "txnActivityYear": 1,
    "provisionAttemptsDay": 1,
    "nbPurchaseAccount": 1,
    "suspiciousAccActivity": "01",
    "shipNameIndicator": "01",
    "paymentAccInd": "03",
    "paymentAccAge": "20181220",
    "acctNumber": "4916994064252017",
    "schemeId": "Visa",
    "payTokenInd": true
  },
  "cardholder": {
    "addrMatch": "N",
    "billAddrCity": "Zurich",
    "billAddrCountry": "756",
    "billAddrLine1": "Zypressenstrasse 71",
    "billAddrLine2": "P.O. Box",
    "billAddrLine3": "8040 Zürich",
    "billAddrPostCode": "8000",
    "billAddrState": "CH",
    "email": "netcetera@example.com",
    "homePhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "mobilePhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "workPhone": {
      "cc": "1",
      "subscriber": "123"
    },
    "cardholderName": "John Doe",
    "shipAddrCity": "Zurich",
    "shipAddrCountry": "756",
    "shipAddrLine1": "Zypressenstrasse 98",
    "shipAddrLine2": "P.O. Box",
    "shipAddrLine3": "8040 Zürich",
    "shipAddrPostCode": "8000",
    "shipAddrState": "CH"
  },
  "purchase": {
    "purchaseInstalData": 3,
    "merchantRiskIndicator": {
      "shipIndicator": "01",
      "deliveryTimeframe": "02",
      "deliveryEmailAddress": "netcetera@example.com",
      "reorderItemsInd": "01",
      "preOrderPurchaseInd": "01",
      "preOrderDate": "20181220",
      "giftCardAmount": 2,
      "giftCardCurr": "978",
      "giftCardCount": 1
    },
    "purchaseAmount": 1,
    "purchaseCurrency": "978",
    "purchaseExponent": 1,
    "purchaseDate": "20181220173550",
    "recurringExpiry": "20181220",
    "recurringFrequency": 1,
    "transType": "01"
  },
  "acquirer": {
    "acquirerBin": "acq-bin",
    "acquirerMerchantId": "acq-mer-id"
  },
  "merchant": {
    "mcc": "0742",
    "merchantCountryCode": "756",
    "merchantName": "name",
    "threeDSRequestorId": "ds-assigned-requestor-id",
    "threeDSRequestorName": "ds-assigned-requestor-name"
  },
  "broadInfo": {"message": "TLS 1.x will be turned off starting summer 2019 "},
  "messageExtension": [
    {
      "name": "name",
      "id": "id",
      "criticalityIndicator": false,
      "data": {
        "valueOne": "value1",
        "valueTwo":"value2"
      }
    }
  ],
  "browserInformation": {
    "browserAcceptHeader": "application/json",
    "browserIP": "192.168.1.11",
    "browserJavaEnabled": true,
    "browserLanguage": "en",
    "browserColorDepth": "8",
    "browserScreenHeight": 1,
    "browserScreenWidth": 1,
    "browserTZ": 1,
    "browserUserAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0",
    "challengeWindowSize": "01"
  }
}
```

#### Response

```json
{
    "threeDSServerTransID": "479f70cc-88fa-47d7-b27e-c261b8ab7aee",
    "acsURL": "https://3dss.extranet.netcetera.biz/3dss-demo/acs/challenge",
    "transStatus": "C",
    "authenticationValue": null,
    "eci": null,
    "acsChallengeMandated": "Y",
    "authenticationRequest": {
        "threeDSCompInd": "Y",
        "threeDSRequestorID": "ds-assigned-requestor-id",
        "threeDSRequestorName": "ds-assigned-requestor-name",
        "threeDSRequestorURL": "https://example.com/3ds-requestor-url",
        "acquirerBIN": "acq-bin",
        "acquirerMerchantID": "acq-mer-id",
        "addrMatch": "N",
        "cardExpiryDate": "1812",
        "acctNumber": "4916994064252017",
        "billAddrCity": "Zurich",
        "billAddrCountry": "756",
        "billAddrLine1": "Zypressenstrasse 71",
        "billAddrLine2": "P.O. Box",
        "billAddrLine3": "8040 Zürich",
        "billAddrPostCode": "8000",
        "billAddrState": "CH",
        "email": "netcetera@example.com",
        "homePhone": {
            "cc": "1",
            "subscriber": "123"
        },
        "mobilePhone": {
            "cc": "1",
            "subscriber": "123"
        }
    },
    "authenticationResponse": {
        "threeDSServerTransID": "479f70cc-88fa-47d7-b27e-c261b8ab7aee",
        "acsTransID": "392d48b3-16e9-41ca-8a93-28ad54cfe61b",
        "acsReferenceNumber": "3DS_LOA_ACS_201_13579",
        "acsOperatorID": "AcsOpId 4138359541",
        "dsReferenceNumber": "DS186937449533647030",
        "dsTransID": "7c8a817f-2195-4cf3-b137-9fe0d0de5676",
        "sdkTransID": null,
        "transStatus": "C",
        "acsChallengeMandated": "Y",
        "messageType": "ARes",
        "messageVersion": "2.1.0"
    },
    "purchaseDate": "20181220173550",
    "errorDetails": null,
    "challengeRequest": {
        "threeDSServerTransID": "479f70cc-88fa-47d7-b27e-c261b8ab7aee",
        "acsTransID": "392d48b3-16e9-41ca-8a93-28ad54cfe61b",
        "messageType": "CReq",
        "messageVersion": "2.1.0",
        "challengeWindowSize": "01",
        "messageExtension": null
    },
    "base64EncodedChallengeRequest": "eyJtZXNzYWdlVHlwZSI6IkNSZXEiLCJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjQ3OWY3MGNjLTg4ZmEtNDdkNy1iMjdlLWMyNjFiOGFiN2FlZSIsImFjc1RyYW5zSUQiOiIzOTJkNDhiMy0xNmU5LTQxY2EtOGE5My0yOGFkNTRjZmU2MWIiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0"
}
```

### 
