 

IPAddresses:

ssh ccpgw@10.160.30.95

ssh ccpgw@10.160.30.93



Mapping to KeyCloak on SIT Server

```bash
ssh -A -t -l gbo nemo.truteq.com -L 8182:localhost:8181 ssh -A -t -l truteq 10.160.12.81 -b 192.168.224.1 -L 8181:localhost:8181

ssh -A -t -l gbo skippy -L 38181:10.160.30.95:8181
```



KeyClock access

http://localhost:38181/

```
username: admin
password: K3yCl04kAdm1n1969
```

PMPLPACPROXY0301	172.16.41.85	Reverse Proxy
PMPLPACPROXY0302	172.16.41.90	Reverse Proxy

Set the revese proxies

External:

vim /etc/httpd/conf.d/ssl.conf

vim /etc/httpd/conf.d/truteq.conf

apachectl restart



Internal reverse proxy

vim ~/CCPGW-Docker-Data/reversehttp/config/extra/httpd-ssl.conf
