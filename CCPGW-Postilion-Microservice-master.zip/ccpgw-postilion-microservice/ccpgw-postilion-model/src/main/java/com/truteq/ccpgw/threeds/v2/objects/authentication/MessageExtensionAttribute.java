/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.truteq.ccpgw.threeds.v2.objects.authentication;

/**
 *
 * @author Grant Blaise O'Reilly <gbo@truteq.com>
 */
public class MessageExtensionAttribute {
    private String name;
    private String id;
    private Boolean criticalityIndicator;
    private Data data;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the criticalityIndicator
     */
    public Boolean getCriticalityIndicator() {
        return criticalityIndicator;
    }

    /**
     * @param criticalityIndicator the criticalityIndicator to set
     */
    public void setCriticalityIndicator(Boolean criticalityIndicator) {
        this.criticalityIndicator = criticalityIndicator;
    }

    /**
     * @return the data
     */
    public Data getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(Data data) {
        this.data = data;
    }
}
