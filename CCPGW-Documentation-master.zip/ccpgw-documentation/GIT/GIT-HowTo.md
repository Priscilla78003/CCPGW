# Creating a branch



```bash
git checkout -b SIT
```

```bash
git checkout -b SIT
Switched to a new branch 'SIT'

git branch
* SIT
  master

```

##### Commiting to Origin on new branch

```bash
git push origin SIT
Username for 'http://factory.platformpac:3000': gbo
Password for 'http://gbo@factory.platformpac:3000': 
Total 0 (delta 0), reused 0 (delta 0)
remote: 
remote: Create a new pull request for 'SIT':
remote:   http://factory.platformpac:3000/gbo/CCPGW-Frontend-Adapters/compare/master...SIT
remote: 
remote: . Processing 1 references
remote: Processed 1 references in total
To http://factory.platformpac:3000/gbo/CCPGW-Frontend-Adapters.git
 * [new branch]      SIT -> SIT

```



# Creating a DEV branch

```bash
git checkout -b DEV
Switched to a new branch 'DEV'
```

```bash
git branch
* DEV
  SIT
  master
```

# Creating a branch



```bash
git checkout -b SIT
```

```bash
git checkout -b SIT
Switched to a new branch 'SIT'

git branch
* SIT
  master

```

##### Commiting DEV to Origin 

```bash
git push origin DEV
Username for 'http://factory.platformpac:3000': gbo
Password for 'http://gbo@factory.platformpac:3000': 
Total 0 (delta 0), reused 0 (delta 0)
remote: 
remote: Create a new pull request for 'DEV':
remote:   http://factory.platformpac:3000/gbo/CCPGW-Frontend-Adapters/compare/master...DEV
remote: 
remote: . Processing 1 references
remote: Processed 1 references in total
To http://factory.platformpac:3000/gbo/CCPGW-Frontend-Adapters.git
 * [new branch]      DEV -> DEV
```



# Merge

**Note:** `git merge` merges the specified branch into the currently active branch. So we need to be on the branch that we are **merging into**.

If you're merging a new feature into the main branch, you first want to switch to the main branch and then merge into it:

```bash
#...develop some code...

$ git add –A
$ git commit –m "Some commit message"
$ git checkout master
# Switched to branch 'master'
$ git merge new-branch
```


If all goes well then our job is done. The new feature commits now appear in the main branch. However, it is possible that Git won't be able to complete the merge due to a conflict change in the source branch. This is called a merge conflict.

If you'd like to read more about Merge Conflicts, how they can arise and how to resolve them - read our Git: Guide to Resolving Merge Conflicts!

To summarize, here are the commands to create a new branch, make some commits, and merge it back into master:

```bash

$ git checkout master
$ git branch new-branch
$ git checkout new-branch
...develop some code...

$ git add –A
$ git commit –m "Some commit message"
$ git checkout master
$ git merge new-branch
```

## Merge process example

![](images/MergeProcessExample.png)



# References

https://www.varonis.com/blog/git-branching#:~:text=What%20is%20Git%20Branching%3F,without%20modifying%20the%20existing%20version

https://devconnected.com/how-to-switch-branch-on-git/ 

https://stackabuse.com/git-merge-branch-into-master/
